Writing D#scribe code is very easy and intuitive - anyone can start right away, without much training whatsoever. We have a list of short article to get you started - you can pick up a topic, or just click next:     
  
[[• Lists | DescribeGrammar-lists]]  
[[• Comments | DescribeGrammar-comments]]  
[[• Links | DescribeGrammar-links]]  
[[• Decorators | DescribeGrammar-decorators]]  
[[• Tags | DescribeGrammar-tags]]  
[[• More on Tags| DescribeGrammar-tagging]]  
[[• Directives | DescribeGrammar-directives]]  
[[• Dot Notation | DescribeGrammar-dot-notation]]  
[[• Slash Notation | DescribeGrammar-slash-notation]]  
[[• Files | DescribeGrammar-filenames]]  
  
  
[[Next ➤|https://github.com/viktorchernev/DescribeCompiler/wiki/DescribeGrammar-lists]]
