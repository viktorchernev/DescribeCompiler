Below is an example output on the low verbosity setting:  
![logs low verbosity](https://github.com/viktorchernev/DescribeCompiler/assets/72315339/1006c3ee-422c-49eb-ac78-2e235af810d1)
