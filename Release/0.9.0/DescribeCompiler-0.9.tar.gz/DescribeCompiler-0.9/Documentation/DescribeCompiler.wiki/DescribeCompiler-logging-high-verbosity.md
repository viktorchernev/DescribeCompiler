Below is an example output on the high verbosity setting:  
![logs high verbosity](https://github.com/viktorchernev/DescribeCompiler/assets/72315339/e6b24622-3a17-4b51-ae3a-a1746dbdb7d5)
