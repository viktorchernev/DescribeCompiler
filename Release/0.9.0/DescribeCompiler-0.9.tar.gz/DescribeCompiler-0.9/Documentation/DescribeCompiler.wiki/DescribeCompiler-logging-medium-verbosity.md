Below is an example output on the medium verbosity setting:  
![logs medium verbosity](https://github.com/viktorchernev/DescribeCompiler/assets/72315339/43c71792-6c82-41a5-ae08-1aaba079b065)
