Currently, you have two options for compiling Describe code - use the command line compiler or use the API in the form of a dll file that you add to your .NET project. There is going to be a JavaScript port in the future.  
  
[[Use the CLI version ➤| https://github.com/viktorchernev/DescribeCompiler/wiki/CliCompiler-how-to]]  
[[Use the API version ➤| https://github.com/viktorchernev/DescribeCompiler/wiki/ApiCompiler-how-to]]