---
layout: page
title: Describe Compiler API - PreprocessorForDescribe08
permalink: /technical/api/preprocessors/prepreprocessor-v08/
exclude: true
---
<span style="color:blue">```string ProcessSource(string value)```</span>
Preprocess Describe source code.<br>
<span style="color:orange">value</span> - The source code string to be preprocessed.<br>
<span style="color:orange">returns</span> - The preprocessed source code string.<br>