---
layout: page
title: DescribeParser.Visitors namespace - Log Visitors
permalink: /tanspiler/parser/visitors/log/
exclude: true
---
The Log visitor classes are mostly for debugging purposes. These visitors draw the parse tree to the Console, and to a Log variable.


[Universal Log Visitor for Describe](/tanspiler/parser/visitors/log/universal/)<br>
[Log Visitor for Describe 0.6](/tanspiler/parser/visitors/log/v06/)<br>
[Log Visitor for Describe 0.7](/tanspiler/parser/visitors/log/v07/)<br>
[Log Visitor for Describe 0.8](/tanspiler/parser/visitors/log/v08/)<br>
[Log Visitor for Describe 0.9](/tanspiler/parser/visitors/log/v09/)<br>
[Log Visitor for Describe 1.0](/tanspiler/parser/visitors/log/v10/)<br>
[Log Visitor for Describe 1.1](/tanspiler/parser/visitors/log/v11/)<br>


### Links
[Back](/tanspiler/parser/visitors/)