---
layout: page
title: Short TimeStamp Optional Template for JSON
permalink: /v092/features/feature-10
exclude: true
---
_FEATURE: Short TimeStamp Optional Template for JSON Translator_

<span style="color:blue">```{SHORT_TIME_STAMP}``` Optional template added to the inbuilt JSON translator.</span>
