---
layout: page
title: Optimizer for Describe v0.6
permalink: /v093/features/feature-2
exclude: true
---
_FEATURE: Optimizer for Describe v0.6_

<span style="color:blue">Specific optimizer for Describe v0.6 has been developed and implemented.</span>
