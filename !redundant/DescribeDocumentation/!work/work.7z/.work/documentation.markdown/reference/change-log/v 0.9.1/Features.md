---
layout: page
title: Features
permalink: /v091/features/
exclude: true
---
_Features implemented in Describe Compiler v0.9.1_

* [CLI - Implement template command](/v091/features/feature-1)
* [CLI - Implement ext command](/v091/features/feature-2)
* [CLI - Refactor message generation](/v091/features/feature-3)
* [CLI - Refactor CLI argument handling](/v091/features/feature-4)
* [Decorators on titles](/v091/features/feature-5)
