---
layout: page
title: Bugs
permalink: /v093/bugs/
exclude: true
---
_Bugs in Describe Compiler v0.9.3_

* [CLI - Console color on exit](/v093/bugs/bug-1)
* [Press any key after parse](/v093/bugs/bug-2)
* [Custom decorators produce bad JSON](/v093/bugs/bug-3)
