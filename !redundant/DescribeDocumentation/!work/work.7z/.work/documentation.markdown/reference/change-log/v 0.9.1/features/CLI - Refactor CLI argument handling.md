---
layout: page
title: CLI - Refactor CLI argument handling
permalink: /v091/features/feature-4
exclude: true
---
_FEATURE: Refactor CLI argument handling_

Refactoring ```DescribeCompilerCLI``` so that different arguments are handled in separate methods, improving readability.

<span style="color:blue">Refactoring has been done.</span>
