---
layout: page
title: Bugs
permalink: /v09/bugs/
exclude: true
---
_Bugs fixed in Describe Compiler v0.9_

* [Consecutive closing semicolons](/v09/bugs/bug-1)
* [Cyrillic or special character](/v09/bugs/bug-2)
* [Empty production null reference](/v09/bugs/bug-3)
* [EscapeEscape does not show](/v09/bugs/bug-4)
* [Last item comment Runaway group](/v09/bugs/bug-5)
* [One letter bug](/v09/bugs/bug-6)
* [Redefinition bug](/v09/bugs/bug-7)
