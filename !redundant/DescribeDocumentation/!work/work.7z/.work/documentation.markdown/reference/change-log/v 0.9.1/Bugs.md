---
layout: page
title: Bugs
permalink: /v091/bugs/
exclude: true
---
_Bugs fixed in Describe Compiler v0.9.1_

* [CLI - Invalid Output Argument](/v091/bugs/bug-1)
* [Star Comments](/v091/bugs/bug-2)
* [Wrong position in error message](/v091/bugs/bug-3)
* [Unclickable links in production heads](/v091/bugs/bug-4)
