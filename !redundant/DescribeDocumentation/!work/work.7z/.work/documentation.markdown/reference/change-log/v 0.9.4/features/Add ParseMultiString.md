---
layout: page
title: Add ParseMultiString
permalink: /v094/features/feature-2
exclude: true
---
_FEATURE: Add ParseMultiString_

<span style="color:blue">Added ParseMultiString method for parsing source codes directly, instead of reading files</span>
