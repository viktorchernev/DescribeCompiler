---
layout: page
title: Features
permalink: /v094/features/
exclude: true
---
_Features implemented in Describe Compiler v0.9.4_

* [Add DescribeCompiler.AWS](/v094/features/feature-1)
* [Add ParseMultiString](/v094/features/feature-2)
* [Add ParseString](/v094/features/feature-3)
* [CLI - Fatal error stack trace option](/v094/features/feature-4)
* [CLI CORE - Dockerable](/v094/features/feature-5)
