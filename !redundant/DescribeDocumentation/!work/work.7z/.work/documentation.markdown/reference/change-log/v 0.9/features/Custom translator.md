---
layout: page
title: Custom translator
permalink: /v09/features/feature-8
exclude: true
---
_FEATURE: Custom Translator_

It should be possible for custom translator class to be implemented.

<span style="color:blue">Feature has been implemented.</span>
