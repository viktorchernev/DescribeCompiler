---
layout: page
title: CLI - Fatal error stack trace option
permalink: /v094/features/feature-4
exclude: true
---
_FEATURE: Fatal error stack trace option_

<span style="color:blue">Added a bool option and fuctionality to include stack traces with fatal error logging</span>
