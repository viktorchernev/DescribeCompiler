---
layout: page
title: Consecutive closing semicolons
permalink: /v09/bugs/bug-1
exclude: true
---
_BUG: Consecutive Closing semicolons_

<span style="color:red">When having multiple closing semicolons sometimes there is an error when we reach closing the root level production.</span>

To be investigated further

<span style="color:green">Was not able to reproduce it later on</span>
