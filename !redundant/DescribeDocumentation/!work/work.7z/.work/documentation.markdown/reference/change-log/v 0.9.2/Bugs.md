---
layout: page
title: Bugs
permalink: /v092/bugs/
exclude: true
---
_Bugs fixed in Describe Compiler v0.9.2_

* [CLI - Red 0 tokens](/v092/bugs/bug-1)
* [CLI - Missing template message](/v092/bugs/bug-2)
* [Same id](/v092/bugs/bug-3)
* [Single digits in timestamp](/v092/bugs/bug-4)
