---
layout: page
title: Remove external templating
permalink: /v093/features/feature-5
exclude: true
---
_FEATURE: Remove external templating functionality_

The functionality to externalize templates and use external template files has been removed, as it is unnecessary, at least at this point, and will only needlessly and substantially complicate the development of the project.
