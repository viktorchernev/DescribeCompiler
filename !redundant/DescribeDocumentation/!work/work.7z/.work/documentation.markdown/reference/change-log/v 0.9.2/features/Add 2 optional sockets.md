---
layout: page
title: Add 2 optional sockets
permalink: /v092/features/feature-7
exclude: true
---
_FEATURE: Add 2 optional sockets_

Implement 2 optional sockets - "TIME_STAMP" and "VERSION"

<span style="color:blue">Users can now include those sockets in a top level stencil "Page", which will result in adding text about the time of compilation and compiler full version, respectively</span>
