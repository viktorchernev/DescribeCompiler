---
layout: page
title: Empty item decorator
permalink: /v09/features/feature-5
exclude: true
---
_FEATURE: Empty item decorator_

<span style="color:blue">Items marked with the ```{empty}``` decorator should be translated to empty list items in HTML, in order to facilitate adding blank lines to HTML lists.
Feature has been implemented.</span>
