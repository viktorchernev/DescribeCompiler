---
layout: page
title: Add ParseString
permalink: /v094/features/feature-3
exclude: true
---
_FEATURE: Add ParseString_

<span style="color:blue">Added ParseString method for parsing source code directly, instead of reading files</span>
