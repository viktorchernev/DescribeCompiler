---
layout: page
title: Features
permalink: /v092/features/
exclude: true
---
_Features implemented in Describe Compiler v0.9.2_

* [CLI - Artifacts argument](/v092/features/feature-1)
* [CLI - Save log to a file](/v092/features/feature-2)
* [CLI - Stop on error](/v092/features/feature-3)
* [Artifacts argument](/v092/features/feature-4)
* [Custom decorator for JSON translator](/v092/features/feature-5)
* [NLComment decorator](/v092/features/feature-6)
* [Add 2 optional sockets](/v092/features/feature-7)
* [Separate translator classes](/v092/features/feature-8)
* [Short Version Optional Template for JSON](/v092/features/feature-9)
* [Short TimeStamp Optional Template for JSON](/v092/features/feature-10)
* [Short Version Optional Socket for HTML](/v092/features/feature-11)
* [Short TimeStamp Optional Socket for HTML](/v092/features/feature-12)
* [Stop on error](/v092/features/feature-13)
* [Optional sockets](/v092/features/feature-14)
