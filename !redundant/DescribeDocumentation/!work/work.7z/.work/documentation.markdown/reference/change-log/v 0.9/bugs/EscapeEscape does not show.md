---
layout: page
title: EscapeEscape does not show
permalink: /v09/bugs/bug-4
exclude: true
---
_BUG: EscapeEscape does not show_

<span style="color:red">ESCAPE ESCAPE "\" does not show as a symbol in HTML.</span>

<span style="color:green">simple bug with handling the text chunk symbol in ```private static string DoTextChunk(Reduction r)``` in Optimizations</span>
