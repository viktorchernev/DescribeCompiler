---
layout: page
title: API Refactoring
permalink: /v093/features/feature-6
exclude: true
---
_FEATURE: Refactoring_

Refactoring and restructuring of folders in the API project has been done.
