---
layout: page
title: CLI - Refactor message generation
permalink: /v091/features/feature-3
exclude: true
---
_FEATURE: Refactor message generation_

Refactor ```DescribeCompilerCLI``` so that messages are generated in their own static class.

<span style="color:blue">Refactoring has been done.</span>
