---
layout: page
title: Stop on error
permalink: /v092/features/feature-13
exclude: true
---
_FEATURE: Stop on error_

The CLI app reads an argument that says weather the compiler should stop if there is an error in source code, or skip the file and continue with the compilation process.

<span style="color:blue">In the API, this functionality has been added too</span>
