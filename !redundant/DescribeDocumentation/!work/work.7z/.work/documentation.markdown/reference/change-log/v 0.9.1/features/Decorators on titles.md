---
layout: page
title: Decorators on titles
permalink: /v091/features/feature-5
exclude: true
---
_FEATURE: Decorators on titles_

Decorators not working on title items (items that have productions).

<span style="color:blue">Simply the functionality was missing and has now been implemented.</span>

```
shopska salad (385) {color|green} ->
		
	150g cucumber (29),
	450g tomatoes (158),
	75g sirene (198);
```
