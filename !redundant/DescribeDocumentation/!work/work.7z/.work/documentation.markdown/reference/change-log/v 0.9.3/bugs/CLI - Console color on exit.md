---
layout: page
title: CLI - Console color on exit
permalink: /v093/bugs/bug-1
exclude: true
---
_BUG: Console color on exit_

<span style="color:red">Should change the color of the console back before exiting the CLI app.</span>

<span style="color:green">Code has been added to fix the issue.</span>
