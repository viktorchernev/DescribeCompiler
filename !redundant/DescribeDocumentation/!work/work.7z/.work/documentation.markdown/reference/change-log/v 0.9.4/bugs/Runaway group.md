---
layout: page
title: Runaway group
permalink: /v094/bugs/todo-bug-2
exclude: true
---
_BUG: Runaway group_

<span style="color:red">The folowing code produced runaway group. To be investegated!!!</span>

```
directives -> namespace <treeofall.public.unsorted>;

Koenigsegg
[https://www.supercars.net/blog/all-brands/koenigsegg/koenigsegg-models/] 
<koenigsegg> ->

    Koenigsegg CC Prototype (1994) (1 Unit),
    Koenigsegg CC8S (2002–2003) (6 units),
    Koenigsegg CCR (2004–2006) (14 units),
    Koenigsegg CCX (2006–2010) (29 units),
    Koenigsegg CCGT (2007) (1 unit),
    Koenigsegg CCXR (2007–2009) (9 units),
    Koenigsegg CCX Edition (2008) (2 units),
    Koenigsegg CCXR Edition (2008) (4 units),
    Koenigsegg CCXR Special (2008–2009) (2 units),
    Koenigsegg CCXR Trevita (2008–2009) (2 units),
    Koenigsegg Quant Concept (2009),
    Koenigsegg Agera (2011) (7 units),
    Koenigsegg Agera R (2011–2014) (18 units),
    Koenigsegg Agera S (2013–2014) (5 units),
    Koenigsegg One:1 (2014–2015) (6 units + 1 prot),
    Koenigsegg Agera RS (2015–2018) (25 units),
    Koenigsegg Agera Final Edition (2018) (3 units),
    Koenigsegg Regera (2016–present) (*80 units),
    Koenigsegg Jesko (2021–) (125 units*),
    Koenigsegg Jesko Absolut (2021–) (125 units*),
    Koenigsegg Gemera (2022–) (*300 units),
    Koenigsegg CC850 (2023-) (*70 units);

//*Units planned, the Jesko and Jesko Absolut have a combined production run of 125 units
```
