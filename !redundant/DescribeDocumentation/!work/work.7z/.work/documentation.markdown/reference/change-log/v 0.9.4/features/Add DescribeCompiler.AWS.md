---
layout: page
title: DescribeCompiler.AWS
permalink: /v094/features/feature-1
exclude: true
---
_FEATURE: DescribeCompiler.AWS_

<span style="color:blue">The project DescribeCompiler.AWS has been added.</span>

<span style="color:blue">It is a version of the describe compiler that runs in an Amazon Web Services Lambda.</span>
