---
layout: page
title: CLI - Red 0 tokens
permalink: /v092/bugs/bug-1
exclude: true
---
_BUG: Red 0 tokens_

<span style="color:red">We get the CLI output saying that - "Parser red 0 tokens in 0 reductions."</span>

<span style="color:green">Feature wasn't implemented for medium and low verbosity. Code has been added to fix the issue.</span>
