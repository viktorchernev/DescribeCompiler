---
layout: page
title: Short TimeStamp Optional Socket for HTML
permalink: /v092/features/feature-12
exclude: true
---
_FEATURE: Short TimeStamp Optional Socket for HTML Translator_

<span style="color:blue">```{SHORT_TIME_STAMP}``` Optional template added to the inbuilt HTML translator.</span> Note that the socket is not included in the default Page template for the HTML translator
