---
layout: page
title: Describe Official
permalink: /v093/features/feature-1
exclude: true
---
_Feature: Implement Describe v 1.0 (Official)_

<span style="color:blue">Describe language version 1.0 (aka Official) has been developed and implemented.</span>
