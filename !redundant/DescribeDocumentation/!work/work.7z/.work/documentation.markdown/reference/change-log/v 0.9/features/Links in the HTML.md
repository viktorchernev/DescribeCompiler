---
layout: page
title: Links in the HTML
permalink: /v09/features/feature-2
exclude: true
---
_FEATURE: Add code to have links in the HTML_

<span style="color:blue">Code added in Translations ```string TranslateProduction(DescribeUnfold u, string id)``` and ```string TranslateItem(DescribeUnfold u, string id)```</span>
