---
layout: page
title: Translation templates names
permalink: /v09/features/feature-6
exclude: true
---
_FEATURE: Translation templates names_

<span style="color:blue">Translation templates names are searched only by filename and the extension is ignored. This way, user can more easily add his own templates and recompile the compiler. He/she still need to make those embedded resources, though.</span>
