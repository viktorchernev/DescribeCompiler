---
layout: page
title: CLI - Stop on error
permalink: /v092/features/feature-3
exclude: true
---
_FEATURE: Stop on error_

<span style="color:blue">The CLI app reads an argument that says weather the compiler should stop if there is an error in source code, or skip the file and continue with the compilation process.</span>

<span style="color:blue">In the API, this functionality has been added too</span>
