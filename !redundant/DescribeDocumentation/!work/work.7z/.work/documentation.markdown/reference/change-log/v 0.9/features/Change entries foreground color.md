---
layout: page
title: Change entries foreground color
permalink: /v09/features/feature-1
exclude: true
---
_FEATURE: Add the functionality to change entries foreground color_

<span style="color:blue">Added - use the decorator ```{color:VALUE}``` where value is a CSS compatible color value.</span>
