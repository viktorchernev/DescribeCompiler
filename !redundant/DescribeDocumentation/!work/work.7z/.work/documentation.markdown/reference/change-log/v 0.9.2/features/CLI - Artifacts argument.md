---
layout: page
title: CLI - Artifacts argument
permalink: /v092/features/feature-4
exclude: true
---
_FEATURE: Artifacts_

Artifacts are compiled snippets that are kept at a specified location, that are used in the compilation process instead of recompiling anew, in case there is no change to the original file

<span style="color:blue">Code has been added to add the 2 corresponding command line arguments and functionality to the CLI app</span>
