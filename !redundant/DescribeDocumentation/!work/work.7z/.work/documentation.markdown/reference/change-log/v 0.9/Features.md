---
layout: page
title: Features
permalink: /v09/features/
exclude: true
---
_Features implemented in Describe Compiler v0.9_

* [Change entries foreground color](/v09/features/feature-1)
* [Links in the HTML](/v09/features/feature-2)
* [Auto-escape symbols](/v09/features/feature-3)
* [Comment item decorator](/v09/features/feature-4)
* [Empty item decorator](/v09/features/feature-5)
* [Translation templates names](/v09/features/feature-6)
* [Namespace addressing scheme](/v09/features/feature-7)
