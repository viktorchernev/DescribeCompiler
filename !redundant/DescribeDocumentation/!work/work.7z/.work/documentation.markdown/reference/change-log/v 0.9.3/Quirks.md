---
layout: page
title: Quirks
permalink: /v093/quirks/
exclude: true
---
_Quirks fixed in Describe Compiler v0.9.3_

* [Text Link Text](/v093/quirks/quirk-1)
