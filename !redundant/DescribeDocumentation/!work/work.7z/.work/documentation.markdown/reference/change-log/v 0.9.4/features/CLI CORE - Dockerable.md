---
layout: page
title: CLI CORE - Dockerable
permalink: /v094/features/feature-5
exclude: true
---
_CLI CORE - Dockerable_

<span style="color:blue">Added docker support and the image runs conteinerized</span>
