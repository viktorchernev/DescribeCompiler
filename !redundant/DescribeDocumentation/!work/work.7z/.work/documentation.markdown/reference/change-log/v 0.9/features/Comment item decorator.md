---
layout: page
title: Comment item decorator
permalink: /v09/features/feature-4
exclude: true
---
_FEATURE: Comment item decorator_

Items marked with the ```{comment}``` decorator should be translated to green and italicized list items in HTML, in order to be used like comment text.

<span style="color:blue">Feature has been implemented.</span>
