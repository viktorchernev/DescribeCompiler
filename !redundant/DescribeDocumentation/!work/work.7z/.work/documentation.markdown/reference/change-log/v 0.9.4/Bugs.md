---
layout: page
title: Bugs
permalink: /v094/bugs/
exclude: true
---
_Bugs in Describe Compiler v0.9.4_

* [CLI CORE - Cannot read console keys](/v094/bugs/bug-1)
* [CLI CORE - Operation not supported](/v094/bugs/bug-2)

### Unsolved:
* [AWS - Lambda memory.md](/v094/bugs/todo-bug-1)
* [Runaway group.md](/v094/bugs/todo-bug-2)
