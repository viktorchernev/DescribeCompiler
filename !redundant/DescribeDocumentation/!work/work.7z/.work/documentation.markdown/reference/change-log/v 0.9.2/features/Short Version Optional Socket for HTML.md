---
layout: page
title: Short Version Optional Socket for HTML
permalink: /v092/features/feature-11
exclude: true
---
_FEATURE: Short Version Optional Socket for HTML Translator_

<span style="color:blue">{SHORT_VERSION} Optional template added to the inbuilt HTML translator.</span> Note that the socket is not included in the default Page template for the HTML translator
