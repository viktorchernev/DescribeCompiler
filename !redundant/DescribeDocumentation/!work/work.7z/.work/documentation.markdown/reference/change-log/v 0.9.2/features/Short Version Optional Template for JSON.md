---
layout: page
title: Short Version Optional Template for JSON
permalink: /v092/features/feature-9
exclude: true
---
_FEATURE: Short Version Optional Template for JSON Translator_

<span style="color:blue">```{SHORT_VERSION}``` Optional template added to the inbuilt JSON translator</span>
