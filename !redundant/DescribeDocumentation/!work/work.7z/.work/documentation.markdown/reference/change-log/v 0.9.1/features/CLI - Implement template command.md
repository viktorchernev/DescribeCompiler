---
layout: page
title: CLI - Implement template command
permalink: /v091/features/feature-1
exclude: true
---
_FEATURE: CLI - Implement template command_

The template command sets the template set to be used. For example ```template=HTML_PARACORD```

<span style="color:blue">Feature has been implemented.</span>
