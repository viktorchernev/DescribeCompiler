---
layout: page
title: Describe Transpiler - Technical Reference
permalink: /language/reference/
exclude: true
---
The Describe markup language is parsed and translated to various destination languages. This is done by the Describe Transpiler, which is written in C#. 
Below you can find technical reference for the transpiler, as well as change-log and testing documentation.


### Links
[Describe Transpiler - Technical Reference](/tanspiler/home/)<br>
[Describe Transpiler - Change log and Versioning](/versioning/)<br>
[Describe Transpiler - Various tests and testing data](/testing/)<br>
[Back](/language/)