========================================
Source Code (between the arrows)
========================================

🡆fabrics <QuvD4gqX> ->        // dude;

    wool fabrics <VBsu8OpW>, /* comment <*/
/* -> {decorator} Comments, man [https://www.notube.com/watch?v=hTui12lKus] */     cotton fabrics <0RdNAvNs> {dec} [https://www.notube.com/watch?v=hTui12lKus];🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "QuvD4gqX" 

    .Productions
        "QuvD4gqX" -> "VBsu8OpW", "0RdNAvNs";

    .Translations
        "QuvD4gqX" - "fabrics"
        "VBsu8OpW" - "wool fabrics"
        "0RdNAvNs" - "cotton fabrics"

    .Links
        "QuvD4gqX" - 
        "VBsu8OpW" - 
        "0RdNAvNs" - "https://www.notube.com/watch?v=hTui12lKus"

    .Decorators
        "QuvD4gqX" - 
        "VBsu8OpW" - 
        "0RdNAvNs" - "dec"

    .Tildes

    .ProdidFile
        "QuvD4gqX" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.B_comments3.ds"

    .ItemidFile
        "QuvD4gqX" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.B_comments3.ds"
        "VBsu8OpW" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.B_comments3.ds"
        "0RdNAvNs" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.B_comments3.ds"

