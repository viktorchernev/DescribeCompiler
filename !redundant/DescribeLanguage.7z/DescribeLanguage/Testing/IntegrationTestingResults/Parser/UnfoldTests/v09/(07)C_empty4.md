========================================
Source Code (between the arrows)
========================================

🡆fabrics
<SIrifQYp>
-> 

;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "SIrifQYp" 

    .Productions
    .Translations
        "SIrifQYp" - "fabrics"

    .Links
        "SIrifQYp" - 

    .Decorators
        "SIrifQYp" - 

    .Tildes

    .ProdidFile
        "SIrifQYp" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.C_empty4.ds"

    .ItemidFile
        "SIrifQYp" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.C_empty4.ds"

