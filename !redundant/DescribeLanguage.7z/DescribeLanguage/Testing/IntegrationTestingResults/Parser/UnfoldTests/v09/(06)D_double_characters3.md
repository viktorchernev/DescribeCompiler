========================================
Source Code (between the arrows)
========================================

🡆fa \ br\ics\ ->

    wool\fabrics,
    \cotton fabrics,
    \ silk \ fabrics,
    synthetic fabrics;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "GKPD4FLQ" 

    .Productions
        "GKPD4FLQ" -> "70VNC3ZK", "75JPRALR", "WUEI86O7", "KLQ3ROIB";

    .Translations
        "GKPD4FLQ" - "fa \ br\ics\"
        "70VNC3ZK" - "wool\fabrics"
        "75JPRALR" - "\cotton fabrics"
        "WUEI86O7" - "\ silk \ fabrics"
        "KLQ3ROIB" - "synthetic fabrics"

    .Links
        "GKPD4FLQ" - 
        "70VNC3ZK" - 
        "75JPRALR" - 
        "WUEI86O7" - 
        "KLQ3ROIB" - 

    .Decorators
        "GKPD4FLQ" - 
        "70VNC3ZK" - 
        "75JPRALR" - 
        "WUEI86O7" - 
        "KLQ3ROIB" - 

    .Tildes

    .ProdidFile
        "GKPD4FLQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters3.ds"

    .ItemidFile
        "GKPD4FLQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters3.ds"
        "70VNC3ZK" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters3.ds"
        "75JPRALR" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters3.ds"
        "WUEI86O7" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters3.ds"
        "KLQ3ROIB" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters3.ds"

