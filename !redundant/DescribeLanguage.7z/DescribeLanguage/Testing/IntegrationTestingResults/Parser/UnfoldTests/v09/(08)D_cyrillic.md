========================================
Source Code (between the arrows)
========================================

🡆платове <ФЛГмссД> ->

	вълнени платове <ПеП0ТхЗй>[https://www.домейн.com/watch?v=hTui12lKus],
	памучни платове <ПТъЗАфЪа>[https://www.notube.com/watch?v=hTui12lKus],
	копринени платове <5Суак3ИЙ>,
	синтетични платове <ЛКтрт5КН>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "ФЛГмссД" 

    .Productions
        "ФЛГмссД" -> "ПеП0ТхЗй", "ПТъЗАфЪа", "5Суак3ИЙ", "ЛКтрт5КН";

    .Translations
        "ФЛГмссД" - "платове"
        "ПеП0ТхЗй" - "вълнени платове"
        "ПТъЗАфЪа" - "памучни платове"
        "5Суак3ИЙ" - "копринени платове"
        "ЛКтрт5КН" - "синтетични платове"

    .Links
        "ФЛГмссД" - 
        "ПеП0ТхЗй" - "https://www.домейн.com/watch?v=hTui12lKus"
        "ПТъЗАфЪа" - "https://www.notube.com/watch?v=hTui12lKus"
        "5Суак3ИЙ" - 
        "ЛКтрт5КН" - 

    .Decorators
        "ФЛГмссД" - 
        "ПеП0ТхЗй" - 
        "ПТъЗАфЪа" - 
        "5Суак3ИЙ" - 
        "ЛКтрт5КН" - 

    .Tildes

    .ProdidFile
        "ФЛГмссД" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_cyrillic.ds"

    .ItemidFile
        "ФЛГмссД" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_cyrillic.ds"
        "ПеП0ТхЗй" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_cyrillic.ds"
        "ПТъЗАфЪа" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_cyrillic.ds"
        "5Суак3ИЙ" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_cyrillic.ds"
        "ЛКтрт5КН" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_cyrillic.ds"

