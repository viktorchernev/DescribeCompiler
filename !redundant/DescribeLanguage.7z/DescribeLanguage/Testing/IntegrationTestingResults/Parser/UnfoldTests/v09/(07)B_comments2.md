========================================
Source Code (between the arrows)
========================================

🡆fabrics <aXLBEer9> -> // comment here

    /* wool fabrics <VevA2Eh3>, */
    cotton fabrics <evhAIQx4>,
    silk fabrics <h0e5wwEY>,
    synthetic fabrics <WryZrSIJ>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "aXLBEer9" 

    .Productions
        "aXLBEer9" -> "evhAIQx4", "h0e5wwEY", "WryZrSIJ";

    .Translations
        "aXLBEer9" - "fabrics"
        "evhAIQx4" - "cotton fabrics"
        "h0e5wwEY" - "silk fabrics"
        "WryZrSIJ" - "synthetic fabrics"

    .Links
        "aXLBEer9" - 
        "evhAIQx4" - 
        "h0e5wwEY" - 
        "WryZrSIJ" - 

    .Decorators
        "aXLBEer9" - 
        "evhAIQx4" - 
        "h0e5wwEY" - 
        "WryZrSIJ" - 

    .Tildes

    .ProdidFile
        "aXLBEer9" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments2.ds"

    .ItemidFile
        "aXLBEer9" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments2.ds"
        "evhAIQx4" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments2.ds"
        "h0e5wwEY" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments2.ds"
        "WryZrSIJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments2.ds"

