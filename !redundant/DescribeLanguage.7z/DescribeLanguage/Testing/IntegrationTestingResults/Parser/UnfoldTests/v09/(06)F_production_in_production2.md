========================================
Source Code (between the arrows)
========================================

🡆macronutrients ->

    water,
	fiber ->

        what,
        not;;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "1ZHB1LRK" 

    .Productions
        "MQQGV8U2" -> "V6JDQGA1", "OYMO0RS4";
        "1ZHB1LRK" -> "YRR99RCQ", "MQQGV8U2";

    .Translations
        "1ZHB1LRK" - "macronutrients"
        "YRR99RCQ" - "water"
        "MQQGV8U2" - "fiber"
        "V6JDQGA1" - "what"
        "OYMO0RS4" - "not"

    .Links
        "1ZHB1LRK" - 
        "YRR99RCQ" - 
        "MQQGV8U2" - 
        "V6JDQGA1" - 
        "OYMO0RS4" - 

    .Decorators
        "1ZHB1LRK" - 
        "YRR99RCQ" - 
        "MQQGV8U2" - 
        "V6JDQGA1" - 
        "OYMO0RS4" - 

    .Tildes

    .ProdidFile
        "MQQGV8U2" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production2.ds"
        "1ZHB1LRK" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production2.ds"

    .ItemidFile
        "1ZHB1LRK" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production2.ds"
        "YRR99RCQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production2.ds"
        "MQQGV8U2" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production2.ds"
        "V6JDQGA1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production2.ds"
        "OYMO0RS4" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production2.ds"

