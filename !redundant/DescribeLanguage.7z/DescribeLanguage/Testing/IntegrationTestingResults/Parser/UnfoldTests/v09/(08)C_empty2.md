========================================
Source Code (between the arrows)
========================================

🡆fabrics <YACUz3H9> [https://www.notube.com/watch?v=hTui12lKus]->;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "YACUz3H9" 

    .Productions
    .Translations
        "YACUz3H9" - "fabrics"

    .Links
        "YACUz3H9" - "https://www.notube.com/watch?v=hTui12lKus"

    .Decorators
        "YACUz3H9" - 

    .Tildes

    .ProdidFile
        "YACUz3H9" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.C_empty2.ds"

    .ItemidFile
        "YACUz3H9" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.C_empty2.ds"

