========================================
Source Code (between the arrows)
========================================

🡆fabrics -> ;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "2R5XG724" 

    .Productions
    .Translations
        "2R5XG724" - "fabrics"

    .Links
        "2R5XG724" - 

    .Decorators
        "2R5XG724" - 

    .Tildes

    .ProdidFile
        "2R5XG724" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty3.ds"

    .ItemidFile
        "2R5XG724" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty3.ds"

