========================================
Source Code (between the arrows)
========================================

🡆fabrics [https://www.notube.com/watch?v=hTui12lKus]-> 
	
	synthetic fabrics https://some-link/
	<i1NLckN6> 
	[https://www.notube.com/watch?v=hTui12lKus]
	{
		info | more info here
	}
	;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "TOVJ9KGK" 

    .Productions
        "TOVJ9KGK" -> "i1NLckN6";

    .Translations
        "TOVJ9KGK" - "fabrics"
        "i1NLckN6" - "synthetic fabrics https://some-link/"

    .Links
        "TOVJ9KGK" - "https://www.notube.com/watch?v=hTui12lKus"
        "i1NLckN6" - "https://www.notube.com/watch?v=hTui12lKus"

    .Decorators
        "TOVJ9KGK" - 
        "i1NLckN6" -  | "more info here"

    .Tildes

    .ProdidFile
        "TOVJ9KGK" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.A_basic2.ds"

    .ItemidFile
        "TOVJ9KGK" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.A_basic2.ds"
        "i1NLckN6" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.A_basic2.ds"

