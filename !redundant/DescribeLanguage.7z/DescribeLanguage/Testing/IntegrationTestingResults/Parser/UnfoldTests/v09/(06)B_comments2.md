========================================
Source Code (between the arrows)
========================================

🡆fabrics -> // comment here

    /* wool fabrics, */
    cotton fabrics,
    silk fabrics,
    synthetic fabrics;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "CS3BI7PR" 

    .Productions
        "CS3BI7PR" -> "4BN8Y468", "Y8ZMYBEG", "8DM3NQX1";

    .Translations
        "CS3BI7PR" - "fabrics"
        "4BN8Y468" - "cotton fabrics"
        "Y8ZMYBEG" - "silk fabrics"
        "8DM3NQX1" - "synthetic fabrics"

    .Links
        "CS3BI7PR" - 
        "4BN8Y468" - 
        "Y8ZMYBEG" - 
        "8DM3NQX1" - 

    .Decorators
        "CS3BI7PR" - 
        "4BN8Y468" - 
        "Y8ZMYBEG" - 
        "8DM3NQX1" - 

    .Tildes

    .ProdidFile
        "CS3BI7PR" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments2.ds"

    .ItemidFile
        "CS3BI7PR" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments2.ds"
        "4BN8Y468" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments2.ds"
        "Y8ZMYBEG" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments2.ds"
        "8DM3NQX1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments2.ds"

