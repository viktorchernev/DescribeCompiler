========================================
Source Code (between the arrows)
========================================

🡆macronutrients <xkQxOfc9> ->

    fiber <CbALGP8d> ->

        what <7KNUmetK>,
        not <6qFQ0HxK>;
	
	science <o8lvOnlB> ->
		
		math <SbQjE2YS>,
		informathics <CVOSiiAS>,
		medicine <1G0hZLJ4>;
    
    water <ozhHnNOU>,
    salt <jMBLOKGE>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "xkQxOfc9" 

    .Productions
        "CbALGP8d" -> "7KNUmetK", "6qFQ0HxK";
        "o8lvOnlB" -> "SbQjE2YS", "CVOSiiAS", "1G0hZLJ4";
        "xkQxOfc9" -> "CbALGP8d", "o8lvOnlB", "ozhHnNOU", "jMBLOKGE";

    .Translations
        "xkQxOfc9" - "macronutrients"
        "CbALGP8d" - "fiber"
        "7KNUmetK" - "what"
        "6qFQ0HxK" - "not"
        "o8lvOnlB" - "science"
        "SbQjE2YS" - "math"
        "CVOSiiAS" - "informathics"
        "1G0hZLJ4" - "medicine"
        "ozhHnNOU" - "water"
        "jMBLOKGE" - "salt"

    .Links
        "xkQxOfc9" - 
        "CbALGP8d" - 
        "7KNUmetK" - 
        "6qFQ0HxK" - 
        "o8lvOnlB" - 
        "SbQjE2YS" - 
        "CVOSiiAS" - 
        "1G0hZLJ4" - 
        "ozhHnNOU" - 
        "jMBLOKGE" - 

    .Decorators
        "xkQxOfc9" - 
        "CbALGP8d" - 
        "7KNUmetK" - 
        "6qFQ0HxK" - 
        "o8lvOnlB" - 
        "SbQjE2YS" - 
        "CVOSiiAS" - 
        "1G0hZLJ4" - 
        "ozhHnNOU" - 
        "jMBLOKGE" - 

    .Tildes

    .ProdidFile
        "CbALGP8d" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "o8lvOnlB" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "xkQxOfc9" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"

    .ItemidFile
        "xkQxOfc9" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "CbALGP8d" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "7KNUmetK" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "6qFQ0HxK" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "o8lvOnlB" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "SbQjE2YS" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "CVOSiiAS" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "1G0hZLJ4" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "ozhHnNOU" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"
        "jMBLOKGE" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production4.ds"

