========================================
Source Code (between the arrows)
========================================

🡆fabrics ->;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "MF0T5NG1" 

    .Productions
    .Translations
        "MF0T5NG1" - "fabrics"

    .Links
        "MF0T5NG1" - 

    .Decorators
        "MF0T5NG1" - 

    .Tildes

    .ProdidFile
        "MF0T5NG1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty1.ds"

    .ItemidFile
        "MF0T5NG1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty1.ds"

