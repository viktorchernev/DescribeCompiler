========================================
Source Code (between the arrows)
========================================

🡆fa brics <6O4fovPJ>->

    wool fabrics <cTk1qeGz>,
    cotton fabrics \[[https://www.notube.com/watch?v=hTui12lKus]<evssLum4>,
    silk \[https://www.notube.com/watch?v=hTui12lKus\]fabrics<WR31xpLW>,
    synthetic fabrics <sfObQkOm>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "6O4fovPJ" 

    .Productions
        "6O4fovPJ" -> "cTk1qeGz", "evssLum4", "WR31xpLW", "sfObQkOm";

    .Translations
        "6O4fovPJ" - "fa brics"
        "cTk1qeGz" - "wool fabrics"
        "evssLum4" - "cotton fabrics \["
        "WR31xpLW" - "silk \[https://www.notube.com/watch?v=hTui12lKus\]fabrics"
        "sfObQkOm" - "synthetic fabrics"

    .Links
        "6O4fovPJ" - 
        "cTk1qeGz" - 
        "evssLum4" - "https://www.notube.com/watch?v=hTui12lKus"
        "WR31xpLW" - 
        "sfObQkOm" - 

    .Decorators
        "6O4fovPJ" - 
        "cTk1qeGz" - 
        "evssLum4" - 
        "WR31xpLW" - 
        "sfObQkOm" - 

    .Tildes

    .ProdidFile
        "6O4fovPJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_escaped_double_characters1.ds"

    .ItemidFile
        "6O4fovPJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_escaped_double_characters1.ds"
        "cTk1qeGz" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_escaped_double_characters1.ds"
        "evssLum4" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_escaped_double_characters1.ds"
        "WR31xpLW" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_escaped_double_characters1.ds"
        "sfObQkOm" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.D_escaped_double_characters1.ds"

