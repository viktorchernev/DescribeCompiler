========================================
Source Code (between the arrows)
========================================

🡆платове <ФЛГмссД5> ->

	вълнени платове <ПеП0ТхЗй>,
	памучни платове <ПТъЗАфЪа>,
	копринени платове <5Суак3ИЙ>,
	синтетични платове <ЛКтрт5КН>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "ФЛГмссД5" 

    .Productions
        "ФЛГмссД5" -> "ПеП0ТхЗй", "ПТъЗАфЪа", "5Суак3ИЙ", "ЛКтрт5КН";

    .Translations
        "ФЛГмссД5" - "платове"
        "ПеП0ТхЗй" - "вълнени платове"
        "ПТъЗАфЪа" - "памучни платове"
        "5Суак3ИЙ" - "копринени платове"
        "ЛКтрт5КН" - "синтетични платове"

    .Links
        "ФЛГмссД5" - 
        "ПеП0ТхЗй" - 
        "ПТъЗАфЪа" - 
        "5Суак3ИЙ" - 
        "ЛКтрт5КН" - 

    .Decorators
        "ФЛГмссД5" - 
        "ПеП0ТхЗй" - 
        "ПТъЗАфЪа" - 
        "5Суак3ИЙ" - 
        "ЛКтрт5КН" - 

    .Tildes

    .ProdidFile
        "ФЛГмссД5" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_cyrillic.ds"

    .ItemidFile
        "ФЛГмссД5" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_cyrillic.ds"
        "ПеП0ТхЗй" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_cyrillic.ds"
        "ПТъЗАфЪа" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_cyrillic.ds"
        "5Суак3ИЙ" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_cyrillic.ds"
        "ЛКтрт5КН" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_cyrillic.ds"

