========================================
Source Code (between the arrows)
========================================

🡆fa \-> br\->ics\-> <uqkUXoj0>->

    wool\->fabrics <y3rd1tuM>,
    \->cotton fabrics<l9JX2YWw>,
    \-> silk \-> fabrics  <INIKQpj4>  ,
    synthetic fabrics\-><gF7eKSgr> ;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "uqkUXoj0" 

    .Productions
        "uqkUXoj0" -> "y3rd1tuM", "l9JX2YWw", "INIKQpj4", "gF7eKSgr";

    .Translations
        "uqkUXoj0" - "fa \-> br\->ics\->"
        "y3rd1tuM" - "wool\->fabrics"
        "l9JX2YWw" - "\->cotton fabrics"
        "INIKQpj4" - "\-> silk \-> fabrics"
        "gF7eKSgr" - "synthetic fabrics\->"

    .Links
        "uqkUXoj0" - 
        "y3rd1tuM" - 
        "l9JX2YWw" - 
        "INIKQpj4" - 
        "gF7eKSgr" - 

    .Decorators
        "uqkUXoj0" - 
        "y3rd1tuM" - 
        "l9JX2YWw" - 
        "INIKQpj4" - 
        "gF7eKSgr" - 

    .Tildes

    .ProdidFile
        "uqkUXoj0" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters1.ds"

    .ItemidFile
        "uqkUXoj0" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters1.ds"
        "y3rd1tuM" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters1.ds"
        "l9JX2YWw" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters1.ds"
        "INIKQpj4" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters1.ds"
        "gF7eKSgr" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters1.ds"

