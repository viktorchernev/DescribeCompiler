========================================
Source Code (between the arrows)
========================================

🡆fabrics
<SIrifQYp>
[https://www.notube.com/watch?v=hTui12lKus]
[https://www.notube.com/watch?v=hTui12lKus]
[]
-> 

;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "SIrifQYp" 

    .Productions
    .Translations
        "SIrifQYp" - "fabrics"

    .Links

        "SIrifQYp" -
            "https://www.notube.com/watch?v=hTui12lKus"
            "https://www.notube.com/watch?v=hTui12lKus"


    .Decorators
        "SIrifQYp" - 

    .Tildes

    .ProdidFile
        "SIrifQYp" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.C_empty3.ds"

    .ItemidFile
        "SIrifQYp" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.C_empty3.ds"

