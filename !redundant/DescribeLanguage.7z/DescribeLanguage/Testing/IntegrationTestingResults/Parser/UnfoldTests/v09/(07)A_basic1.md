========================================
Source Code (between the arrows)
========================================

🡆fabrics <QpeudYXy> ->

	wool fabrics <54vHCQwI>,
	cotton fabrics <Ll0bDtIQ>,
	silk fabrics <6huM44Hm>,
	synthetic fabrics <oAgVUPi0>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "QpeudYXy" 

    .Productions
        "QpeudYXy" -> "54vHCQwI", "Ll0bDtIQ", "6huM44Hm", "oAgVUPi0";

    .Translations
        "QpeudYXy" - "fabrics"
        "54vHCQwI" - "wool fabrics"
        "Ll0bDtIQ" - "cotton fabrics"
        "6huM44Hm" - "silk fabrics"
        "oAgVUPi0" - "synthetic fabrics"

    .Links
        "QpeudYXy" - 
        "54vHCQwI" - 
        "Ll0bDtIQ" - 
        "6huM44Hm" - 
        "oAgVUPi0" - 

    .Decorators
        "QpeudYXy" - 
        "54vHCQwI" - 
        "Ll0bDtIQ" - 
        "6huM44Hm" - 
        "oAgVUPi0" - 

    .Tildes

    .ProdidFile
        "QpeudYXy" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic1.ds"

    .ItemidFile
        "QpeudYXy" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic1.ds"
        "54vHCQwI" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic1.ds"
        "Ll0bDtIQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic1.ds"
        "6huM44Hm" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic1.ds"
        "oAgVUPi0" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic1.ds"

