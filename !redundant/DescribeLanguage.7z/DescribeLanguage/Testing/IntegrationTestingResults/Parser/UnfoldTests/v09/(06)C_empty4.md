========================================
Source Code (between the arrows)
========================================

🡆fabrics -> 

;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "LTTUHOU1" 

    .Productions
    .Translations
        "LTTUHOU1" - "fabrics"

    .Links
        "LTTUHOU1" - 

    .Decorators
        "LTTUHOU1" - 

    .Tildes

    .ProdidFile
        "LTTUHOU1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty4.ds"

    .ItemidFile
        "LTTUHOU1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty4.ds"

