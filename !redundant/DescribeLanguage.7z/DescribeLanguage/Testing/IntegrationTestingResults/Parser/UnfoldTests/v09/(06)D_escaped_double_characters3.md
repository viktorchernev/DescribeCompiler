========================================
Source Code (between the arrows)
========================================

🡆fa \\ br\\ics\\ ->

    wool\\fabrics,
    \\cotton fabrics,
    \\ silk \\ fabrics,
    synthetic fabrics\\;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "B22ZU4HQ" 

    .Productions
        "B22ZU4HQ" -> "53EAO6AX", "6CAW33HL", "8VTX9MYD", "VF0U4EIM";

    .Translations
        "B22ZU4HQ" - "fa \\ br\\ics\\"
        "53EAO6AX" - "wool\\fabrics"
        "6CAW33HL" - "\\cotton fabrics"
        "8VTX9MYD" - "\\ silk \\ fabrics"
        "VF0U4EIM" - "synthetic fabrics\\"

    .Links
        "B22ZU4HQ" - 
        "53EAO6AX" - 
        "6CAW33HL" - 
        "8VTX9MYD" - 
        "VF0U4EIM" - 

    .Decorators
        "B22ZU4HQ" - 
        "53EAO6AX" - 
        "6CAW33HL" - 
        "8VTX9MYD" - 
        "VF0U4EIM" - 

    .Tildes

    .ProdidFile
        "B22ZU4HQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters3.ds"

    .ItemidFile
        "B22ZU4HQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters3.ds"
        "53EAO6AX" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters3.ds"
        "6CAW33HL" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters3.ds"
        "8VTX9MYD" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters3.ds"
        "VF0U4EIM" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters3.ds"

