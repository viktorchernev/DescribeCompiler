========================================
Source Code (between the arrows)
========================================

🡆macronutrients <oVs6tsnU> ->

    water <9Y9uFDwu>,
	fiber <PALnQoTQ>[http://testlink.com/] ->

        what [http://testlink.com/]<6hlYVfaz>,
        not [http://testlink.com/]<gubSBEDe>;

	somth else [http://testlink.com/]<hAyLdw3m>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "oVs6tsnU" 

    .Productions
        "PALnQoTQ" -> "6hlYVfaz", "gubSBEDe";
        "oVs6tsnU" -> "9Y9uFDwu", "PALnQoTQ", "hAyLdw3m";

    .Translations
        "oVs6tsnU" - "macronutrients"
        "9Y9uFDwu" - "water"
        "PALnQoTQ" - "fiber"
        "6hlYVfaz" - "what"
        "gubSBEDe" - "not"
        "hAyLdw3m" - "somth else"

    .Links
        "oVs6tsnU" - 
        "9Y9uFDwu" - 
        "PALnQoTQ" - "http://testlink.com/"
        "6hlYVfaz" - "http://testlink.com/"
        "gubSBEDe" - "http://testlink.com/"
        "hAyLdw3m" - "http://testlink.com/"

    .Decorators
        "oVs6tsnU" - 
        "9Y9uFDwu" - 
        "PALnQoTQ" - 
        "6hlYVfaz" - 
        "gubSBEDe" - 
        "hAyLdw3m" - 

    .Tildes

    .ProdidFile
        "PALnQoTQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production3.ds"
        "oVs6tsnU" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production3.ds"

    .ItemidFile
        "oVs6tsnU" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production3.ds"
        "9Y9uFDwu" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production3.ds"
        "PALnQoTQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production3.ds"
        "6hlYVfaz" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production3.ds"
        "gubSBEDe" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production3.ds"
        "hAyLdw3m" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production3.ds"

