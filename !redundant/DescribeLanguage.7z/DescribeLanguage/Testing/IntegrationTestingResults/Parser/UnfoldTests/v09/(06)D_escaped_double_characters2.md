========================================
Source Code (between the arrows)
========================================

🡆fa \, br\->ics\// ->

    wool\;fabrics,
    \,cotton fabrics,
    silk fabrics,
    synthetic fabrics\;;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "LTE8NVPD" 

    .Productions
        "LTE8NVPD" -> "8VLXAI2R", "9PNG67XU", "QMAD4SLC", "PKJV775U";

    .Translations
        "LTE8NVPD" - "fa \, br\->ics\//"
        "8VLXAI2R" - "wool\;fabrics"
        "9PNG67XU" - "\,cotton fabrics"
        "QMAD4SLC" - "silk fabrics"
        "PKJV775U" - "synthetic fabrics\;"

    .Links
        "LTE8NVPD" - 
        "8VLXAI2R" - 
        "9PNG67XU" - 
        "QMAD4SLC" - 
        "PKJV775U" - 

    .Decorators
        "LTE8NVPD" - 
        "8VLXAI2R" - 
        "9PNG67XU" - 
        "QMAD4SLC" - 
        "PKJV775U" - 

    .Tildes

    .ProdidFile
        "LTE8NVPD" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters2.ds"

    .ItemidFile
        "LTE8NVPD" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters2.ds"
        "8VLXAI2R" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters2.ds"
        "9PNG67XU" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters2.ds"
        "QMAD4SLC" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters2.ds"
        "PKJV775U" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_escaped_double_characters2.ds"

