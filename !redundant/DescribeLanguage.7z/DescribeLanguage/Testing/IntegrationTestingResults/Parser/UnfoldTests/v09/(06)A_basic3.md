========================================
Source Code (between the arrows)
========================================

🡆fabrics -> synthetic fabrics;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "OQZVXWAT" 

    .Productions
        "OQZVXWAT" -> "4KBRC3J5";

    .Translations
        "OQZVXWAT" - "fabrics"
        "4KBRC3J5" - "synthetic fabrics"

    .Links
        "OQZVXWAT" - 
        "4KBRC3J5" - 

    .Decorators
        "OQZVXWAT" - 
        "4KBRC3J5" - 

    .Tildes

    .ProdidFile
        "OQZVXWAT" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.A_basic3.ds"

    .ItemidFile
        "OQZVXWAT" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.A_basic3.ds"
        "4KBRC3J5" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.A_basic3.ds"

