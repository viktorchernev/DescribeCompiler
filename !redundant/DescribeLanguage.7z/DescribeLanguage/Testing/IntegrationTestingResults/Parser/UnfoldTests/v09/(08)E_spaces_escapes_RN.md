========================================
Source Code (between the arrows)
========================================

🡆fabric     s    <sJZOzSdo>[https://www.notube.com/watch?v=hTui12lKus]	->

	wool   fabrics[https://www.notube.com/watch?v=hTui12lKus]	<UlJXGWLS>,
	cotton\, fabrics textiles  \]<d4jKusMe>[https://www.notube.com/watch?v=hTui12lKus],
    silk\[fabrics <Bgx8M6B1>,
    syntic 		fabrics <7vbW9VSB>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "sJZOzSdo" 

    .Productions
        "sJZOzSdo" -> "UlJXGWLS", "d4jKusMe", "Bgx8M6B1", "7vbW9VSB";

    .Translations
        "sJZOzSdo" - "fabric     s"
        "UlJXGWLS" - "wool   fabrics"
        "d4jKusMe" - "cotton\, fabrics textiles  \]"
        "Bgx8M6B1" - "silk\[fabrics"
        "7vbW9VSB" - "syntic 		fabrics"

    .Links
        "sJZOzSdo" - "https://www.notube.com/watch?v=hTui12lKus"
        "UlJXGWLS" - "https://www.notube.com/watch?v=hTui12lKus"
        "d4jKusMe" - "https://www.notube.com/watch?v=hTui12lKus"
        "Bgx8M6B1" - 
        "7vbW9VSB" - 

    .Decorators
        "sJZOzSdo" - 
        "UlJXGWLS" - 
        "d4jKusMe" - 
        "Bgx8M6B1" - 
        "7vbW9VSB" - 

    .Tildes

    .ProdidFile
        "sJZOzSdo" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.E_spaces_escapes_RN.ds"

    .ItemidFile
        "sJZOzSdo" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.E_spaces_escapes_RN.ds"
        "UlJXGWLS" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.E_spaces_escapes_RN.ds"
        "d4jKusMe" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.E_spaces_escapes_RN.ds"
        "Bgx8M6B1" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.E_spaces_escapes_RN.ds"
        "7vbW9VSB" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.E_spaces_escapes_RN.ds"

