========================================
Source Code (between the arrows)
========================================

🡆fa \\ br\\ics\\ <rDD37re8> ->

    wool\\fabrics <uCzQa1uW>,
    \\cotton fabrics <UxMKgYjI>,
    \\ silk \\ fabrics <Ux6wwQBT>,
    synthetic fabrics\\ <dbpyUcza>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "rDD37re8" 

    .Productions
        "rDD37re8" -> "uCzQa1uW", "UxMKgYjI", "Ux6wwQBT", "dbpyUcza";

    .Translations
        "rDD37re8" - "fa \\ br\\ics\\"
        "uCzQa1uW" - "wool\\fabrics"
        "UxMKgYjI" - "\\cotton fabrics"
        "Ux6wwQBT" - "\\ silk \\ fabrics"
        "dbpyUcza" - "synthetic fabrics\\"

    .Links
        "rDD37re8" - 
        "uCzQa1uW" - 
        "UxMKgYjI" - 
        "Ux6wwQBT" - 
        "dbpyUcza" - 

    .Decorators
        "rDD37re8" - 
        "uCzQa1uW" - 
        "UxMKgYjI" - 
        "Ux6wwQBT" - 
        "dbpyUcza" - 

    .Tildes

    .ProdidFile
        "rDD37re8" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters3.ds"

    .ItemidFile
        "rDD37re8" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters3.ds"
        "uCzQa1uW" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters3.ds"
        "UxMKgYjI" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters3.ds"
        "Ux6wwQBT" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters3.ds"
        "dbpyUcza" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters3.ds"

