========================================
Source Code (between the arrows)
========================================

🡆fabrics <xpXWehDW> [https://www.notube.com/watch?v=hTui12lKus]-> // comment here

    wool fabrics <TcD3LcoW>,
    cotton fabrics[https://www.notube.com/watch?v=hTui12lKus] <thZBzyNc>,
    silk fabrics <dOlQGMJ4>[https://www.notube.com/watch?v=hTui12lKus],
    synthetic fabrics <Ln7Y7Dme>[https://www.notube.com/watch?v=hTui12lKus];// comment last🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "xpXWehDW" 

    .Productions
        "xpXWehDW" -> "TcD3LcoW", "thZBzyNc", "dOlQGMJ4", "Ln7Y7Dme";

    .Translations
        "xpXWehDW" - "fabrics"
        "TcD3LcoW" - "wool fabrics"
        "thZBzyNc" - "cotton fabrics"
        "dOlQGMJ4" - "silk fabrics"
        "Ln7Y7Dme" - "synthetic fabrics"

    .Links
        "xpXWehDW" - "https://www.notube.com/watch?v=hTui12lKus"
        "TcD3LcoW" - 
        "thZBzyNc" - "https://www.notube.com/watch?v=hTui12lKus"
        "dOlQGMJ4" - "https://www.notube.com/watch?v=hTui12lKus"
        "Ln7Y7Dme" - "https://www.notube.com/watch?v=hTui12lKus"

    .Decorators
        "xpXWehDW" - 
        "TcD3LcoW" - 
        "thZBzyNc" - 
        "dOlQGMJ4" - 
        "Ln7Y7Dme" - 

    .Tildes

    .ProdidFile
        "xpXWehDW" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.B_comments5.ds"

    .ItemidFile
        "xpXWehDW" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.B_comments5.ds"
        "TcD3LcoW" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.B_comments5.ds"
        "thZBzyNc" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.B_comments5.ds"
        "dOlQGMJ4" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.B_comments5.ds"
        "Ln7Y7Dme" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.B_comments5.ds"

