========================================
Source Code (between the arrows)
========================================

🡆платове ->

	вълнени платове,
	памучни платове,
	копринени платове,
	синтетични платове;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "D1ABQCPC" 

    .Productions
        "D1ABQCPC" -> "CNIIIJRC", "OB452XLL", "69KVKR4P", "1Y80UM9C";

    .Translations
        "D1ABQCPC" - "платове"
        "CNIIIJRC" - "вълнени платове"
        "OB452XLL" - "памучни платове"
        "69KVKR4P" - "копринени платове"
        "1Y80UM9C" - "синтетични платове"

    .Links
        "D1ABQCPC" - 
        "CNIIIJRC" - 
        "OB452XLL" - 
        "69KVKR4P" - 
        "1Y80UM9C" - 

    .Decorators
        "D1ABQCPC" - 
        "CNIIIJRC" - 
        "OB452XLL" - 
        "69KVKR4P" - 
        "1Y80UM9C" - 

    .Tildes

    .ProdidFile
        "D1ABQCPC" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"

    .ItemidFile
        "D1ABQCPC" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"
        "CNIIIJRC" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"
        "OB452XLL" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"
        "69KVKR4P" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"
        "1Y80UM9C" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"

