========================================
Source Code (between the arrows)
========================================

🡆fa \ br\ics\ <AkoHsBxP>->

    wool\fabrics <\2\2gPwg0Z>,
    \cotton fabrics <\6KbLpKF2>,
    \ silk \ fabrics <YA0\Cn7gP>,
    synthetic fabrics\ <V4tLOkb5>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "AkoHsBxP" 

    .Productions
        "AkoHsBxP" -> "\2\2gPwg0Z", "\6KbLpKF2", "YA0\Cn7gP", "V4tLOkb5";

    .Translations
        "AkoHsBxP" - "fa \ br\ics\"
        "\2\2gPwg0Z" - "wool\fabrics"
        "\6KbLpKF2" - "\cotton fabrics"
        "YA0\Cn7gP" - "\ silk \ fabrics"
        "V4tLOkb5" - "synthetic fabrics\"

    .Links
        "AkoHsBxP" - 
        "\2\2gPwg0Z" - 
        "\6KbLpKF2" - 
        "YA0\Cn7gP" - 
        "V4tLOkb5" - 

    .Decorators
        "AkoHsBxP" - 
        "\2\2gPwg0Z" - 
        "\6KbLpKF2" - 
        "YA0\Cn7gP" - 
        "V4tLOkb5" - 

    .Tildes

    .ProdidFile
        "AkoHsBxP" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters3.ds"

    .ItemidFile
        "AkoHsBxP" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters3.ds"
        "\2\2gPwg0Z" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters3.ds"
        "\6KbLpKF2" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters3.ds"
        "YA0\Cn7gP" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters3.ds"
        "V4tLOkb5" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters3.ds"

