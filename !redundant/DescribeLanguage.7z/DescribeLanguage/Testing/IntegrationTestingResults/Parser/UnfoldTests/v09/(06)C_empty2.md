========================================
Source Code (between the arrows)
========================================

🡆fabrics->;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "SD4S4RDA" 

    .Productions
    .Translations
        "SD4S4RDA" - "fabrics"

    .Links
        "SD4S4RDA" - 

    .Decorators
        "SD4S4RDA" - 

    .Tildes

    .ProdidFile
        "SD4S4RDA" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty2.ds"

    .ItemidFile
        "SD4S4RDA" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty2.ds"

