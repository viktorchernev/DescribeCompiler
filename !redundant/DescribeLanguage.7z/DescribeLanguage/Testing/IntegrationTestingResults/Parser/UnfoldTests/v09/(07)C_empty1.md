========================================
Source Code (between the arrows)
========================================

🡆fabrics<c42Q6wPH> ->;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "c42Q6wPH" 

    .Productions
    .Translations
        "c42Q6wPH" - "fabrics"

    .Links
        "c42Q6wPH" - 

    .Decorators
        "c42Q6wPH" - 

    .Tildes

    .ProdidFile
        "c42Q6wPH" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.C_empty1.ds"

    .ItemidFile
        "c42Q6wPH" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.C_empty1.ds"

