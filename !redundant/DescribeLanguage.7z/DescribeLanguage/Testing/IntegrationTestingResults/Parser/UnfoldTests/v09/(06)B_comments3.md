========================================
Source Code (between the arrows)
========================================

🡆fabrics ->        // dude;

    wool fabrics, /* comment <*/
/* ->Comments, man */    cotton fabrics;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "FD5WS6XA" 

    .Productions
        "FD5WS6XA" -> "A6WX8MG6", "TO7TFQ8G";

    .Translations
        "FD5WS6XA" - "fabrics"
        "A6WX8MG6" - "wool fabrics"
        "TO7TFQ8G" - "cotton fabrics"

    .Links
        "FD5WS6XA" - 
        "A6WX8MG6" - 
        "TO7TFQ8G" - 

    .Decorators
        "FD5WS6XA" - 
        "A6WX8MG6" - 
        "TO7TFQ8G" - 

    .Tildes

    .ProdidFile
        "FD5WS6XA" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments3.ds"

    .ItemidFile
        "FD5WS6XA" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments3.ds"
        "A6WX8MG6" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments3.ds"
        "TO7TFQ8G" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments3.ds"

