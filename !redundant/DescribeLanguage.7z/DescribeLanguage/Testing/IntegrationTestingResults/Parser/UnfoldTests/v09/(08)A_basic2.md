========================================
Source Code (between the arrows)
========================================

🡆fabrics [https://www.notube.com/watch?v=hTui12lKus]-> 
	
	synthetic fabrics <i1NLckN6> [https://www.notube.com/watch?v=hTui12lKus];🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "ORG9BI7K" 

    .Productions
        "ORG9BI7K" -> "i1NLckN6";

    .Translations
        "ORG9BI7K" - "fabrics"
        "i1NLckN6" - "synthetic fabrics"

    .Links
        "ORG9BI7K" - "https://www.notube.com/watch?v=hTui12lKus"
        "i1NLckN6" - "https://www.notube.com/watch?v=hTui12lKus"

    .Decorators
        "ORG9BI7K" - 
        "i1NLckN6" - 

    .Tildes

    .ProdidFile
        "ORG9BI7K" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.A_basic2.ds"

    .ItemidFile
        "ORG9BI7K" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.A_basic2.ds"
        "i1NLckN6" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.A_basic2.ds"

