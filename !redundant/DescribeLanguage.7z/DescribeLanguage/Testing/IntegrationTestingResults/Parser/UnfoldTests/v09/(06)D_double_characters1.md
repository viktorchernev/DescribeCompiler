========================================
Source Code (between the arrows)
========================================

🡆fa - br-ics- ->

    wool-fabrics,
    -cotton fabrics,
    - silk - fabrics,
    synthetic fabrics-;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "S4TA23N1" 

    .Productions
        "S4TA23N1" -> "XO84DM6C", "831T9LIN", "K8X35Y42", "G0HYZC01";

    .Translations
        "S4TA23N1" - "fa - br-ics-"
        "XO84DM6C" - "wool-fabrics"
        "831T9LIN" - "-cotton fabrics"
        "K8X35Y42" - "- silk - fabrics"
        "G0HYZC01" - "synthetic fabrics-"

    .Links
        "S4TA23N1" - 
        "XO84DM6C" - 
        "831T9LIN" - 
        "K8X35Y42" - 
        "G0HYZC01" - 

    .Decorators
        "S4TA23N1" - 
        "XO84DM6C" - 
        "831T9LIN" - 
        "K8X35Y42" - 
        "G0HYZC01" - 

    .Tildes

    .ProdidFile
        "S4TA23N1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"

    .ItemidFile
        "S4TA23N1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"
        "XO84DM6C" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"
        "831T9LIN" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"
        "K8X35Y42" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"
        "G0HYZC01" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"

