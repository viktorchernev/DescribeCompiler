========================================
Source Code (between the arrows)
========================================

🡆macronutrients ->

    fiber ->

        what,
        not;
    
    water;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "2TPRU2XA" 

    .Productions
        "DS41YJCQ" -> "ZJSAE7S5", "WGUZ6P6N";
        "2TPRU2XA" -> "DS41YJCQ", "MGWTJTJ3";

    .Translations
        "2TPRU2XA" - "macronutrients"
        "DS41YJCQ" - "fiber"
        "ZJSAE7S5" - "what"
        "WGUZ6P6N" - "not"
        "MGWTJTJ3" - "water"

    .Links
        "2TPRU2XA" - 
        "DS41YJCQ" - 
        "ZJSAE7S5" - 
        "WGUZ6P6N" - 
        "MGWTJTJ3" - 

    .Decorators
        "2TPRU2XA" - 
        "DS41YJCQ" - 
        "ZJSAE7S5" - 
        "WGUZ6P6N" - 
        "MGWTJTJ3" - 

    .Tildes

    .ProdidFile
        "DS41YJCQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "2TPRU2XA" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"

    .ItemidFile
        "2TPRU2XA" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "DS41YJCQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "ZJSAE7S5" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "WGUZ6P6N" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "MGWTJTJ3" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"

