========================================
Source Code (between the arrows)
========================================

🡆fa - br-ics- <45mns0l-O>->

    wool-fabrics <-5g1GJyFS>,
    -cotton fabrics <f75CKWhl->,
    - silk - fabrics <68Es--hujI>,
    synthetic fabrics- <mWa4QdRm>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "45mns0l-O" 

    .Productions
        "45mns0l-O" -> "-5g1GJyFS", "f75CKWhl-", "68Es--hujI", "mWa4QdRm";

    .Translations
        "45mns0l-O" - "fa - br-ics-"
        "-5g1GJyFS" - "wool-fabrics"
        "f75CKWhl-" - "-cotton fabrics"
        "68Es--hujI" - "- silk - fabrics"
        "mWa4QdRm" - "synthetic fabrics-"

    .Links
        "45mns0l-O" - 
        "-5g1GJyFS" - 
        "f75CKWhl-" - 
        "68Es--hujI" - 
        "mWa4QdRm" - 

    .Decorators
        "45mns0l-O" - 
        "-5g1GJyFS" - 
        "f75CKWhl-" - 
        "68Es--hujI" - 
        "mWa4QdRm" - 

    .Tildes

    .ProdidFile
        "45mns0l-O" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters1.ds"

    .ItemidFile
        "45mns0l-O" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters1.ds"
        "-5g1GJyFS" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters1.ds"
        "f75CKWhl-" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters1.ds"
        "68Es--hujI" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters1.ds"
        "mWa4QdRm" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters1.ds"

