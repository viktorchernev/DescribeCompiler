========================================
Source Code (between the arrows)
========================================

🡆fabrics <xpXWehDW> -> // comment here

    wool fabrics <TcD3LcoW>,
    cotton fabrics <thZBzyNc>,
    silk fabrics <dOlQGMJ4>,
    synthetic fabrics <Ln7Y7Dme>;// comment last🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "xpXWehDW" 

    .Productions
        "xpXWehDW" -> "TcD3LcoW", "thZBzyNc", "dOlQGMJ4", "Ln7Y7Dme";

    .Translations
        "xpXWehDW" - "fabrics"
        "TcD3LcoW" - "wool fabrics"
        "thZBzyNc" - "cotton fabrics"
        "dOlQGMJ4" - "silk fabrics"
        "Ln7Y7Dme" - "synthetic fabrics"

    .Links
        "xpXWehDW" - 
        "TcD3LcoW" - 
        "thZBzyNc" - 
        "dOlQGMJ4" - 
        "Ln7Y7Dme" - 

    .Decorators
        "xpXWehDW" - 
        "TcD3LcoW" - 
        "thZBzyNc" - 
        "dOlQGMJ4" - 
        "Ln7Y7Dme" - 

    .Tildes

    .ProdidFile
        "xpXWehDW" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments5.ds"

    .ItemidFile
        "xpXWehDW" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments5.ds"
        "TcD3LcoW" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments5.ds"
        "thZBzyNc" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments5.ds"
        "dOlQGMJ4" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments5.ds"
        "Ln7Y7Dme" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.B_comments5.ds"

