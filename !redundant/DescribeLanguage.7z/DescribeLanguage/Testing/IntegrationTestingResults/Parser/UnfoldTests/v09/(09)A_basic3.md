========================================
Source Code (between the arrows)
========================================

🡆fabrics [https://www.notube.com/watch?v=hTui12lKus] {color | red}<zAfn39Kh>-> synthetic fabrics <hOy5oL3B> ;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "zAfn39Kh" 

    .Productions
        "zAfn39Kh" -> "hOy5oL3B";

    .Translations
        "zAfn39Kh" - "fabrics"
        "hOy5oL3B" - "synthetic fabrics"

    .Links
        "zAfn39Kh" - "https://www.notube.com/watch?v=hTui12lKus"
        "hOy5oL3B" - 

    .Decorators
        "zAfn39Kh" -  | "red"
        "hOy5oL3B" - 

    .Tildes

    .ProdidFile
        "zAfn39Kh" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.A_basic3.ds"

    .ItemidFile
        "zAfn39Kh" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.A_basic3.ds"
        "hOy5oL3B" - "Tests.Integration.Parser.TestFiles.TestFilesFor09.A_basic3.ds"

