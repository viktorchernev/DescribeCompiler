========================================
Source Code (between the arrows)
========================================

🡆fa / br/ics/ <ToUZ5J7e> ->

    wool/fabrics </DZChUWeh>,
    /cotton fabrics <XBru/v3rK>,
    / silk / fabrics<7tewYK/BC>,
    synthetic fabrics/<qStgB/Iqw>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "ToUZ5J7e" 

    .Productions
        "ToUZ5J7e" -> "/DZChUWeh", "XBru/v3rK", "7tewYK/BC", "qStgB/Iqw";

    .Translations
        "ToUZ5J7e" - "fa / br/ics/"
        "/DZChUWeh" - "wool/fabrics"
        "XBru/v3rK" - "/cotton fabrics"
        "7tewYK/BC" - "/ silk / fabrics"
        "qStgB/Iqw" - "synthetic fabrics/"

    .Links
        "ToUZ5J7e" - 
        "/DZChUWeh" - 
        "XBru/v3rK" - 
        "7tewYK/BC" - 
        "qStgB/Iqw" - 

    .Decorators
        "ToUZ5J7e" - 
        "/DZChUWeh" - 
        "XBru/v3rK" - 
        "7tewYK/BC" - 
        "qStgB/Iqw" - 

    .Tildes

    .ProdidFile
        "ToUZ5J7e" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters2.ds"

    .ItemidFile
        "ToUZ5J7e" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters2.ds"
        "/DZChUWeh" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters2.ds"
        "XBru/v3rK" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters2.ds"
        "7tewYK/BC" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters2.ds"
        "qStgB/Iqw" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_double_characters2.ds"

