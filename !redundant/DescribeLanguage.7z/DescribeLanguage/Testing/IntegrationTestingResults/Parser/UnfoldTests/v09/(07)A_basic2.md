========================================
Source Code (between the arrows)
========================================

🡆fabrics -> 
	
	synthetic fabrics <i1NLckN6>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "97DVVN5U" 

    .Productions
        "97DVVN5U" -> "i1NLckN6";

    .Translations
        "97DVVN5U" - "fabrics"
        "i1NLckN6" - "synthetic fabrics"

    .Links
        "97DVVN5U" - 
        "i1NLckN6" - 

    .Decorators
        "97DVVN5U" - 
        "i1NLckN6" - 

    .Tildes

    .ProdidFile
        "97DVVN5U" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic2.ds"

    .ItemidFile
        "97DVVN5U" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic2.ds"
        "i1NLckN6" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.A_basic2.ds"

