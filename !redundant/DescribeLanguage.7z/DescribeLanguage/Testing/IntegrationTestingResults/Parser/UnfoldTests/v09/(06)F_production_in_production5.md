========================================
Source Code (between the arrows)
========================================

🡆macronutrients ->

	water,
    salt,
    fiber ->

        what,
        not;
	
	science ->
		
		math,
		informathics,
		medicine;;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "5SRSVDUJ" 

    .Productions
        "994VNY1Q" -> "FYW5J4FR", "B0XJKLH9";
        "VQSGDZ5Y" -> "09VP8XTG", "Q8J30YFF", "Y4839RKD";
        "5SRSVDUJ" -> "PAITSHLM", "N7MKT52O", "994VNY1Q", "VQSGDZ5Y";

    .Translations
        "5SRSVDUJ" - "macronutrients"
        "PAITSHLM" - "water"
        "N7MKT52O" - "salt"
        "994VNY1Q" - "fiber"
        "FYW5J4FR" - "what"
        "B0XJKLH9" - "not"
        "VQSGDZ5Y" - "science"
        "09VP8XTG" - "math"
        "Q8J30YFF" - "informathics"
        "Y4839RKD" - "medicine"

    .Links
        "5SRSVDUJ" - 
        "PAITSHLM" - 
        "N7MKT52O" - 
        "994VNY1Q" - 
        "FYW5J4FR" - 
        "B0XJKLH9" - 
        "VQSGDZ5Y" - 
        "09VP8XTG" - 
        "Q8J30YFF" - 
        "Y4839RKD" - 

    .Decorators
        "5SRSVDUJ" - 
        "PAITSHLM" - 
        "N7MKT52O" - 
        "994VNY1Q" - 
        "FYW5J4FR" - 
        "B0XJKLH9" - 
        "VQSGDZ5Y" - 
        "09VP8XTG" - 
        "Q8J30YFF" - 
        "Y4839RKD" - 

    .Tildes

    .ProdidFile
        "994VNY1Q" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "VQSGDZ5Y" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "5SRSVDUJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"

    .ItemidFile
        "5SRSVDUJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "PAITSHLM" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "N7MKT52O" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "994VNY1Q" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "FYW5J4FR" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "B0XJKLH9" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "VQSGDZ5Y" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "09VP8XTG" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "Q8J30YFF" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"
        "Y4839RKD" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production5.ds"

