========================================
Source Code (between the arrows)
========================================

🡆macronutrients <VNvl4KbI> ->

    fiber <BNdiPBY8> ->

        what <47GG8irk>,
        not <vRje122z>;
	
	science <4Zohe6QE> ->
		
		math <u87kglXS> ->
			algebra [http://testlink.com/]<VB7KNYBw>,
			geometry <gKznl6RJ>;
			
		informathics <Uon0W1e7>,
		medicine <rBW9kGDK>;
    
    water <3QJz4slg>,
    salt <X2BTGncx>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "VNvl4KbI" 

    .Productions
        "BNdiPBY8" -> "47GG8irk", "vRje122z";
        "u87kglXS" -> "VB7KNYBw", "gKznl6RJ";
        "4Zohe6QE" -> "u87kglXS", "Uon0W1e7", "rBW9kGDK";
        "VNvl4KbI" -> "BNdiPBY8", "4Zohe6QE", "3QJz4slg", "X2BTGncx";

    .Translations
        "VNvl4KbI" - "macronutrients"
        "BNdiPBY8" - "fiber"
        "47GG8irk" - "what"
        "vRje122z" - "not"
        "4Zohe6QE" - "science"
        "u87kglXS" - "math"
        "VB7KNYBw" - "algebra"
        "gKznl6RJ" - "geometry"
        "Uon0W1e7" - "informathics"
        "rBW9kGDK" - "medicine"
        "3QJz4slg" - "water"
        "X2BTGncx" - "salt"

    .Links
        "VNvl4KbI" - 
        "BNdiPBY8" - 
        "47GG8irk" - 
        "vRje122z" - 
        "4Zohe6QE" - 
        "u87kglXS" - 
        "VB7KNYBw" - "http://testlink.com/"
        "gKznl6RJ" - 
        "Uon0W1e7" - 
        "rBW9kGDK" - 
        "3QJz4slg" - 
        "X2BTGncx" - 

    .Decorators
        "VNvl4KbI" - 
        "BNdiPBY8" - 
        "47GG8irk" - 
        "vRje122z" - 
        "4Zohe6QE" - 
        "u87kglXS" - 
        "VB7KNYBw" - 
        "gKznl6RJ" - 
        "Uon0W1e7" - 
        "rBW9kGDK" - 
        "3QJz4slg" - 
        "X2BTGncx" - 

    .Tildes

    .ProdidFile
        "BNdiPBY8" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "u87kglXS" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "4Zohe6QE" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "VNvl4KbI" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"

    .ItemidFile
        "VNvl4KbI" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "BNdiPBY8" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "47GG8irk" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "vRje122z" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "4Zohe6QE" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "u87kglXS" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "VB7KNYBw" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "gKznl6RJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "Uon0W1e7" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "rBW9kGDK" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "3QJz4slg" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"
        "X2BTGncx" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.F_production_in_production6.ds"

