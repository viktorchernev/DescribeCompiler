========================================
Source Code (between the arrows)
========================================

🡆fa \, br\->ics\// <6O4fovPJ>->

    wool\;fabrics <cTk1qeGz>,
    \,cotton fabrics\<<cTk1qeGz>,
    silk fabrics<cTk1qeGz>  ,
    synthetic fabrics\; <cTk1qeGz>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "6O4fovPJ" 

    .Productions
        "6O4fovPJ" -> "cTk1qeGz", "cTk1qeGz", "cTk1qeGz", "cTk1qeGz";

    .Translations
        "6O4fovPJ" - "fa \, br\->ics\//"
        "cTk1qeGz" - "synthetic fabrics\;"

    .Links
        "6O4fovPJ" - 
        "cTk1qeGz" - 

    .Decorators
        "6O4fovPJ" - 
        "cTk1qeGz" - 

    .Tildes

    .ProdidFile
        "6O4fovPJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters2.ds"

    .ItemidFile
        "6O4fovPJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters2.ds"
        "cTk1qeGz" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters2.ds"
            "cTk1qeGz" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters2.ds"
            "cTk1qeGz" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters2.ds"
            "cTk1qeGz" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.D_escaped_double_characters2.ds"

