========================================
Source Code (between the arrows)
========================================

🡆macronutrients ->

    water,
	fiber ->

        what,
        not;

	somth else;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "X8JDSWL4" 

    .Productions
        "VFB0HTJQ" -> "90T1366G", "WCOWCIZ4";
        "X8JDSWL4" -> "3DDN63LG", "VFB0HTJQ", "CEWSMOIW";

    .Translations
        "X8JDSWL4" - "macronutrients"
        "3DDN63LG" - "water"
        "VFB0HTJQ" - "fiber"
        "90T1366G" - "what"
        "WCOWCIZ4" - "not"
        "CEWSMOIW" - "somth else"

    .Links
        "X8JDSWL4" - 
        "3DDN63LG" - 
        "VFB0HTJQ" - 
        "90T1366G" - 
        "WCOWCIZ4" - 
        "CEWSMOIW" - 

    .Decorators
        "X8JDSWL4" - 
        "3DDN63LG" - 
        "VFB0HTJQ" - 
        "90T1366G" - 
        "WCOWCIZ4" - 
        "CEWSMOIW" - 

    .Tildes

    .ProdidFile
        "VFB0HTJQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production3.ds"
        "X8JDSWL4" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production3.ds"

    .ItemidFile
        "X8JDSWL4" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production3.ds"
        "3DDN63LG" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production3.ds"
        "VFB0HTJQ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production3.ds"
        "90T1366G" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production3.ds"
        "WCOWCIZ4" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production3.ds"
        "CEWSMOIW" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production3.ds"

