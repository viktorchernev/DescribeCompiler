========================================
Source Code (between the arrows)
========================================

🡆fabric     s 	<TSbLGnNG> ->

	wool   fabrics	 <QWVZ3pp9> ,
	cotton\, fabrics textiles   <75NTfebY>,
    silk\-\>fabrics <Sqs0lm7S>,
    syntic 		fabrics <GcZEI9gy>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "TSbLGnNG" 

    .Productions
        "TSbLGnNG" -> "QWVZ3pp9", "75NTfebY", "Sqs0lm7S", "GcZEI9gy";

    .Translations
        "TSbLGnNG" - "fabric     s"
        "QWVZ3pp9" - "wool   fabrics"
        "75NTfebY" - "cotton\, fabrics textiles"
        "Sqs0lm7S" - "silk\-\>fabrics"
        "GcZEI9gy" - "syntic 		fabrics"

    .Links
        "TSbLGnNG" - 
        "QWVZ3pp9" - 
        "75NTfebY" - 
        "Sqs0lm7S" - 
        "GcZEI9gy" - 

    .Decorators
        "TSbLGnNG" - 
        "QWVZ3pp9" - 
        "75NTfebY" - 
        "Sqs0lm7S" - 
        "GcZEI9gy" - 

    .Tildes

    .ProdidFile
        "TSbLGnNG" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_N.ds"

    .ItemidFile
        "TSbLGnNG" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_N.ds"
        "QWVZ3pp9" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_N.ds"
        "75NTfebY" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_N.ds"
        "Sqs0lm7S" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_N.ds"
        "GcZEI9gy" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_N.ds"

