========================================
Source Code (between the arrows)
========================================

🡆fabrics<YMFX0PTE>-> ;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "YMFX0PTE" 

    .Productions
    .Translations
        "YMFX0PTE" - "fabrics"

    .Links
        "YMFX0PTE" - 

    .Decorators
        "YMFX0PTE" - 

    .Tildes

    .ProdidFile
        "YMFX0PTE" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.C_empty3.ds"

    .ItemidFile
        "YMFX0PTE" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.C_empty3.ds"

