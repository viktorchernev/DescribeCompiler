========================================
Source Code (between the arrows)
========================================

🡆fabrics -> 
	
	synthetic fabrics;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "SCO6478Y" 

    .Productions
        "SCO6478Y" -> "44RY5M7S";

    .Translations
        "SCO6478Y" - "fabrics"
        "44RY5M7S" - "synthetic fabrics"

    .Links
        "SCO6478Y" - 
        "44RY5M7S" - 

    .Decorators
        "SCO6478Y" - 
        "44RY5M7S" - 

    .Tildes

    .ProdidFile
        "SCO6478Y" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.A_basic2.ds"

    .ItemidFile
        "SCO6478Y" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.A_basic2.ds"
        "44RY5M7S" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.A_basic2.ds"

