========================================
Source Code (between the arrows)
========================================

🡆fabric     s    <sJZOzSdo>	->

	wool   fabrics	<UlJXGWLS> ,
	cotton\, fabrics textiles  \<<d4jKusMe>,
    silk\->fabrics <Bgx8/M6B1>,
    syntic 		fabrics <7vb\\W9VSB>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "sJZOzSdo" 

    .Productions
        "sJZOzSdo" -> "UlJXGWLS", "d4jKusMe", "Bgx8/M6B1", "7vb\\W9VSB";

    .Translations
        "sJZOzSdo" - "fabric     s"
        "UlJXGWLS" - "wool   fabrics"
        "d4jKusMe" - "cotton\, fabrics textiles  \<"
        "Bgx8/M6B1" - "silk\->fabrics"
        "7vb\\W9VSB" - "syntic 		fabrics"

    .Links
        "sJZOzSdo" - 
        "UlJXGWLS" - 
        "d4jKusMe" - 
        "Bgx8/M6B1" - 
        "7vb\\W9VSB" - 

    .Decorators
        "sJZOzSdo" - 
        "UlJXGWLS" - 
        "d4jKusMe" - 
        "Bgx8/M6B1" - 
        "7vb\\W9VSB" - 

    .Tildes

    .ProdidFile
        "sJZOzSdo" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_RN.ds"

    .ItemidFile
        "sJZOzSdo" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_RN.ds"
        "UlJXGWLS" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_RN.ds"
        "d4jKusMe" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_RN.ds"
        "Bgx8/M6B1" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_RN.ds"
        "7vb\\W9VSB" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.E_spaces_escapes_RN.ds"

