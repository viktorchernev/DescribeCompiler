========================================
Source Code (between the arrows)
========================================

🡆macronutrients <0CmyN2Mb> ->

    fiber <CMxWzMs5> ->

        what <hzAzwlx6>,
        not <UHOcZPAm>;
    
    water <BBmOZjJa>;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "0CmyN2Mb" 

    .Productions
        "CMxWzMs5" -> "hzAzwlx6", "UHOcZPAm";
        "0CmyN2Mb" -> "CMxWzMs5", "BBmOZjJa";

    .Translations
        "0CmyN2Mb" - "macronutrients"
        "CMxWzMs5" - "fiber"
        "hzAzwlx6" - "what"
        "UHOcZPAm" - "not"
        "BBmOZjJa" - "water"

    .Links
        "0CmyN2Mb" - 
        "CMxWzMs5" - 
        "hzAzwlx6" - 
        "UHOcZPAm" - 
        "BBmOZjJa" - 

    .Decorators
        "0CmyN2Mb" - 
        "CMxWzMs5" - 
        "hzAzwlx6" - 
        "UHOcZPAm" - 
        "BBmOZjJa" - 

    .Tildes

    .ProdidFile
        "CMxWzMs5" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production1.ds"
        "0CmyN2Mb" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production1.ds"

    .ItemidFile
        "0CmyN2Mb" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production1.ds"
        "CMxWzMs5" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production1.ds"
        "hzAzwlx6" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production1.ds"
        "UHOcZPAm" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production1.ds"
        "BBmOZjJa" - "Tests.Integration.Parser.TestFiles.TestFilesFor07.F_production_in_production1.ds"

