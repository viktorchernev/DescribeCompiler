========================================
Source Code (between the arrows)
========================================

🡆fabrics ->;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "9YFSN7RY" 

    .Productions
    .Translations
        "9YFSN7RY" - "fabrics"

    .Links
        "9YFSN7RY" - 

    .Decorators
        "9YFSN7RY" - 

    .Tildes

    .ProdidFile
        "9YFSN7RY" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty1.ds"

    .ItemidFile
        "9YFSN7RY" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty1.ds"

