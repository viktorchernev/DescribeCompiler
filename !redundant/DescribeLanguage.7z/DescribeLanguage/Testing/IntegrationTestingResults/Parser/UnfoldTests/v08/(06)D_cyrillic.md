========================================
Source Code (between the arrows)
========================================

🡆платове ->

	вълнени платове,
	памучни платове,
	копринени платове,
	синтетични платове;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "R4Q17K0R" 

    .Productions
        "R4Q17K0R" -> "HVY13GLZ", "QGEWJZH9", "XSKF9MB4", "MN8MYF4G";

    .Translations
        "R4Q17K0R" - "платове"
        "HVY13GLZ" - "вълнени платове"
        "QGEWJZH9" - "памучни платове"
        "XSKF9MB4" - "копринени платове"
        "MN8MYF4G" - "синтетични платове"

    .Links
        "R4Q17K0R" - 
        "HVY13GLZ" - 
        "QGEWJZH9" - 
        "XSKF9MB4" - 
        "MN8MYF4G" - 

    .Decorators
        "R4Q17K0R" - 
        "HVY13GLZ" - 
        "QGEWJZH9" - 
        "XSKF9MB4" - 
        "MN8MYF4G" - 

    .Tildes

    .ProdidFile
        "R4Q17K0R" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"

    .ItemidFile
        "R4Q17K0R" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"
        "HVY13GLZ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"
        "QGEWJZH9" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"
        "XSKF9MB4" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"
        "MN8MYF4G" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_cyrillic.ds"

