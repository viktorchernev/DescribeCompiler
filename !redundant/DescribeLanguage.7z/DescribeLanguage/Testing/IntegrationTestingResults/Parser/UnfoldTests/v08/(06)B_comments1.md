========================================
Source Code (between the arrows)
========================================

🡆fabrics -> // comment here

    wool fabrics,
    cotton fabrics,
    silk fabrics,
    synthetic fabrics;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "YSX4I83E" 

    .Productions
        "YSX4I83E" -> "ULKYVR0W", "I7AJHWJS", "4QGM724D", "UX0YEZZA";

    .Translations
        "YSX4I83E" - "fabrics"
        "ULKYVR0W" - "wool fabrics"
        "I7AJHWJS" - "cotton fabrics"
        "4QGM724D" - "silk fabrics"
        "UX0YEZZA" - "synthetic fabrics"

    .Links
        "YSX4I83E" - 
        "ULKYVR0W" - 
        "I7AJHWJS" - 
        "4QGM724D" - 
        "UX0YEZZA" - 

    .Decorators
        "YSX4I83E" - 
        "ULKYVR0W" - 
        "I7AJHWJS" - 
        "4QGM724D" - 
        "UX0YEZZA" - 

    .Tildes

    .ProdidFile
        "YSX4I83E" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments1.ds"

    .ItemidFile
        "YSX4I83E" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments1.ds"
        "ULKYVR0W" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments1.ds"
        "I7AJHWJS" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments1.ds"
        "4QGM724D" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments1.ds"
        "UX0YEZZA" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments1.ds"

