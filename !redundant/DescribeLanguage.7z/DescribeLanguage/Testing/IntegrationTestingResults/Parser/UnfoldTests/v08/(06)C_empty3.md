========================================
Source Code (between the arrows)
========================================

🡆fabrics -> ;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "K506LDK6" 

    .Productions
    .Translations
        "K506LDK6" - "fabrics"

    .Links
        "K506LDK6" - 

    .Decorators
        "K506LDK6" - 

    .Tildes

    .ProdidFile
        "K506LDK6" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty3.ds"

    .ItemidFile
        "K506LDK6" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty3.ds"

