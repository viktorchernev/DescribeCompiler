========================================
Source Code (between the arrows)
========================================

🡆fabrics -> 

;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "R8073LQJ" 

    .Productions
    .Translations
        "R8073LQJ" - "fabrics"

    .Links
        "R8073LQJ" - 

    .Decorators
        "R8073LQJ" - 

    .Tildes

    .ProdidFile
        "R8073LQJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty4.ds"

    .ItemidFile
        "R8073LQJ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.C_empty4.ds"

