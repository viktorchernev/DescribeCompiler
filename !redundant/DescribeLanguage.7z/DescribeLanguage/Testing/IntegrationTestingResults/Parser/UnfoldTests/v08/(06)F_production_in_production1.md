========================================
Source Code (between the arrows)
========================================

🡆macronutrients ->

    fiber ->

        what,
        not;
    
    water;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "RQAVUXWB" 

    .Productions
        "0PRIYNR8" -> "JYRTQO3G", "SLDR7XHO";
        "RQAVUXWB" -> "0PRIYNR8", "J1I6DRK1";

    .Translations
        "RQAVUXWB" - "macronutrients"
        "0PRIYNR8" - "fiber"
        "JYRTQO3G" - "what"
        "SLDR7XHO" - "not"
        "J1I6DRK1" - "water"

    .Links
        "RQAVUXWB" - 
        "0PRIYNR8" - 
        "JYRTQO3G" - 
        "SLDR7XHO" - 
        "J1I6DRK1" - 

    .Decorators
        "RQAVUXWB" - 
        "0PRIYNR8" - 
        "JYRTQO3G" - 
        "SLDR7XHO" - 
        "J1I6DRK1" - 

    .Tildes

    .ProdidFile
        "0PRIYNR8" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "RQAVUXWB" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"

    .ItemidFile
        "RQAVUXWB" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "0PRIYNR8" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "JYRTQO3G" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "SLDR7XHO" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"
        "J1I6DRK1" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.F_production_in_production1.ds"

