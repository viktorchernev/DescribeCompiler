========================================
Source Code (between the arrows)
========================================

🡆fa - br-ics- ->

    wool-fabrics,
    -cotton fabrics,
    - silk - fabrics,
    synthetic fabrics-;🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "E6TCNOTD" 

    .Productions
        "E6TCNOTD" -> "1PTN7D20", "P04DK1BL", "TLLFFBVR", "0HXR0WCC";

    .Translations
        "E6TCNOTD" - "fa - br-ics-"
        "1PTN7D20" - "wool-fabrics"
        "P04DK1BL" - "-cotton fabrics"
        "TLLFFBVR" - "- silk - fabrics"
        "0HXR0WCC" - "synthetic fabrics-"

    .Links
        "E6TCNOTD" - 
        "1PTN7D20" - 
        "P04DK1BL" - 
        "TLLFFBVR" - 
        "0HXR0WCC" - 

    .Decorators
        "E6TCNOTD" - 
        "1PTN7D20" - 
        "P04DK1BL" - 
        "TLLFFBVR" - 
        "0HXR0WCC" - 

    .Tildes

    .ProdidFile
        "E6TCNOTD" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"

    .ItemidFile
        "E6TCNOTD" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"
        "1PTN7D20" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"
        "P04DK1BL" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"
        "TLLFFBVR" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"
        "0HXR0WCC" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.D_double_characters1.ds"

