========================================
Source Code (between the arrows)
========================================

🡆fabrics [https://www.notube.com/watch?v=hTui12lKus]-> 
	
	synthetic fabrics <i1NLckN6> [https://www.notube.com/watch?v=hTui12lKus];🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "AIR6KOI1" 

    .Productions
        "AIR6KOI1" -> "i1NLckN6";

    .Translations
        "AIR6KOI1" - "fabrics"
        "i1NLckN6" - "synthetic fabrics"

    .Links
        "AIR6KOI1" - "https://www.notube.com/watch?v=hTui12lKus"
        "i1NLckN6" - "https://www.notube.com/watch?v=hTui12lKus"

    .Decorators
        "AIR6KOI1" - 
        "i1NLckN6" - 

    .Tildes

    .ProdidFile
        "AIR6KOI1" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.A_basic2.ds"

    .ItemidFile
        "AIR6KOI1" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.A_basic2.ds"
        "i1NLckN6" - "Tests.Integration.Parser.TestFiles.TestFilesFor08.A_basic2.ds"

