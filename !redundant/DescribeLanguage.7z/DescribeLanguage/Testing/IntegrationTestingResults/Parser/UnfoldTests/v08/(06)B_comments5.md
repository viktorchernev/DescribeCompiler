========================================
Source Code (between the arrows)
========================================

🡆fabrics -> // comment here

    wool fabrics,
    cotton fabrics,
    silk fabrics,
    synthetic fabrics;// comment last🡄

========================================
Parse Tree
========================================
DescribeUnfold

    .AllFiles
    .ParsedFiles
    .FailedFiles

    .PrimaryProductions
        "P59K0O64" 

    .Productions
        "P59K0O64" -> "B5KC3EJ0", "77CGYGRU", "KZELNWS0", "ETAEIXLZ";

    .Translations
        "P59K0O64" - "fabrics"
        "B5KC3EJ0" - "wool fabrics"
        "77CGYGRU" - "cotton fabrics"
        "KZELNWS0" - "silk fabrics"
        "ETAEIXLZ" - "synthetic fabrics"

    .Links
        "P59K0O64" - 
        "B5KC3EJ0" - 
        "77CGYGRU" - 
        "KZELNWS0" - 
        "ETAEIXLZ" - 

    .Decorators
        "P59K0O64" - 
        "B5KC3EJ0" - 
        "77CGYGRU" - 
        "KZELNWS0" - 
        "ETAEIXLZ" - 

    .Tildes

    .ProdidFile
        "P59K0O64" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments5.ds"

    .ItemidFile
        "P59K0O64" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments5.ds"
        "B5KC3EJ0" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments5.ds"
        "77CGYGRU" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments5.ds"
        "KZELNWS0" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments5.ds"
        "ETAEIXLZ" - "Tests.Integration.Parser.TestFiles.TestFilesFor06.B_comments5.ds"

