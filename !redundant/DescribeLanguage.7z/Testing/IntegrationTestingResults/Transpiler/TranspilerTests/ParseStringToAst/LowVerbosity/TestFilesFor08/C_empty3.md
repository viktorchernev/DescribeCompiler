========================================
Source Code (between the arrows)
========================================

🡆fabrics
<SIrifQYp>
[https://www.notube.com/watch?v=hTui12lKus]
[https://www.notube.com/watch?v=hTui12lKus]
[]
-> 

;🡄

========================================
Logged text
========================================

🡆Verbosity set to: Low
Language version set to: Describe Links - v0.8
Describe Transpiler initialized.
Starting a 'String -> AST' operation...
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.C_empty3.ds - parsed successfully
Parser red 123 characters, into 9 tokens.
Those were translated to an AST.
All Files: 1, Succeeded: 1, Failed: 0, Errors: 0🡄

========================================
Produced AST
========================================

{"filename":"Tests.Integration.Transpiler.TestFiles.TestFilesFor08.C_empty3.ds","nspace":null,"expressions":[{"title":{"tilde":null,"text":{"leafType":"Text","text":"fabrics","leadingTrivia":"","trailingTrivia":"\r\n"},"tag":{"openBracket":{"leafType":"OpenTag","text":"<","leadingTrivia":"","trailingTrivia":""},"id":{"leafType":"Text","text":"SIrifQYp","leadingTrivia":"","trailingTrivia":""},"closeBracket":{"leafType":"CloseTag","text":">","leadingTrivia":"","trailingTrivia":"\r\n"}},"links":null,"decorators":null},"arrow":{"leafType":"ProductionArrow","text":"->","leadingTrivia":"","trailingTrivia":" \r\n\r\n"},"lines":[{"body":null,"punctuation":{"leafType":"Text","text":";","leadingTrivia":"","trailingTrivia":""}}]}],"exception":null}