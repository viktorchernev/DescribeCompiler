========================================
Source Code File Names (between the arrows)
========================================

🡆Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_decorators.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_decorators2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_links.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_links2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tags.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tags2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tilde.ds🡄

========================================
Logged text
========================================

🡆Verbosity set to: Low
Language version set to: Describe Doubles - v1.1
Describe Transpiler initialized.
Starting a 'String[] -> Unfold[]' operation...
STOP_ON_ERROR - False
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_decorators.ds - parsed successfully
Parser red 127 characters, into 15 tokens.
Those were translated to an AST.
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_decorators2.ds - parsed successfully
Parser red 134 characters, into 24 tokens.
Those were translated to an AST.
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_links.ds - parsed successfully
Parser red 150 characters, into 15 tokens.
Those were translated to an AST.
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_links2.ds - parsed successfully
Parser red 159 characters, into 25 tokens.
Those were translated to an AST.
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tags.ds - parsed successfully
Parser red 117 characters, into 15 tokens.
Those were translated to an AST.
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tags2.ds - parsed successfully
Parser red 121 characters, into 22 tokens.
Those were translated to an AST.
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tilde.ds - parsed successfully
Parser red 124 characters, into 17 tokens.
Those were translated to an AST.
All Files: 7, Succeeded: 7, Failed: 0, Errors: 0🡄

========================================
Produced Unfold
========================================

