========================================
Source Code File Names (between the arrows)
========================================

🡆Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_decorators.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_decorators2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_links.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_links2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tags.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tags2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tilde.ds🡄

========================================
Logged text
========================================

🡆Verbosity set to: Medium
Language version set to: Describe Doubles - v1.1
Describe Transpiler initialized.
Starting a 'String[] -> Unfold[]' operation...
STOP_ON_ERROR - False
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_decorators.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 127 characters, into 15 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_decorators2.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 134 characters, into 24 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_links.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 150 characters, into 15 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_links2.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 159 characters, into 25 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tags.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 117 characters, into 15 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tags2.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 121 characters, into 22 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor11.A_tilde.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 124 characters, into 17 tokens.
Those were translated to an AST.
All Files: 7, Succeeded: 7, Failed: 0, Errors: 0🡄

========================================
Produced Unfold
========================================

