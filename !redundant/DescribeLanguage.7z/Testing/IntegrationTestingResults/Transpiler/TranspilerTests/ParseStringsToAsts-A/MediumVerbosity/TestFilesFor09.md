========================================
Source Code File Names (between the arrows)
========================================

🡆Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_twoRoots.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments5.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.C_cyrillic.ds🡄

========================================
Logged text
========================================

🡆Verbosity set to: Medium
Language version set to: Describe Decorators - v0.9
Describe Transpiler initialized.
Starting a 'String[] -> Unfold[]' operation...
STOP_ON_ERROR - False
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic1.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 363 characters, into 32 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic2.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 193 characters, into 15 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic3.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 108 characters, into 10 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic4.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 432 characters, into 30 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_twoRoots.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 332 characters, into 26 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments1.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 336 characters, into 23 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments2.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 275 characters, into 16 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments3.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 245 characters, into 13 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments4.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 400 characters, into 23 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments5.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 365 characters, into 21 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.C_cyrillic.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 274 characters, into 22 tokens.
Those were translated to an AST.
All Files: 11, Succeeded: 11, Failed: 0, Errors: 0🡄

========================================
Produced Unfold
========================================

