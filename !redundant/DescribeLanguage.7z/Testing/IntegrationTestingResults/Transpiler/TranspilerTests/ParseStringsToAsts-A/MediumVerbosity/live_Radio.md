========================================
Source Code File Names (between the arrows)
========================================

🡆Tests.Integration.Transpiler.TestFiles.live_Radio.City.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.City.2024-04-15.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.City.2024-04-16.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.City.2024-04-17.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Energy.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Energy.2024-04-15.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Energy.2024-04-16.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Energy.2024-04-17.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.NovaNews.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.NovaNews.2024-04-15.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.NovaNews.2024-04-16.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.NovaNews.2024-04-17.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Radio1Rock.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Radio1Rock.2024-04-15.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Radio1Rock.2024-04-16.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Radio1Rock.2024-04-17.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.radiowatch.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Veselina.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Veselina.2024-04-15.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Veselina.2024-04-16.ds
Tests.Integration.Transpiler.TestFiles.live_Radio.Veselina.2024-04-17.ds🡄

========================================
Logged text
========================================

🡆Verbosity set to: Medium
Language version set to: Describe Lines - v1.0
Describe Transpiler initialized.
Starting a 'String[] -> Unfold[]' operation...
STOP_ON_ERROR - False
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.City.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 149 characters, into 17 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.City.2024-04-15.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 10195 characters, into 1350 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.City.2024-04-16.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 10313 characters, into 1406 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.City.2024-04-17.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 10096 characters, into 1372 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Energy.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 159 characters, into 17 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Energy.2024-04-15.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 10409 characters, into 1373 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Energy.2024-04-16.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 10653 characters, into 1349 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Energy.2024-04-17.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 9592 characters, into 1287 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.NovaNews.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 164 characters, into 17 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.NovaNews.2024-04-15.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 9984 characters, into 1169 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.NovaNews.2024-04-16.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 9868 characters, into 1207 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.NovaNews.2024-04-17.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 7053 characters, into 824 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Radio1Rock.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 163 characters, into 17 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Radio1Rock.2024-04-15.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 9673 characters, into 1241 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Radio1Rock.2024-04-16.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 9358 characters, into 1213 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Radio1Rock.2024-04-17.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 6888 characters, into 899 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.radiowatch.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 242 characters, into 23 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Veselina.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 169 characters, into 17 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Veselina.2024-04-15.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 5761 characters, into 771 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Veselina.2024-04-16.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 6181 characters, into 807 tokens.
Those were translated to an AST.
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.live_Radio.Veselina.2024-04-17.ds"
Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 3737 characters, into 491 tokens.
Those were translated to an AST.
All Files: 21, Succeeded: 21, Failed: 0, Errors: 0🡄

========================================
Produced Unfold
========================================

