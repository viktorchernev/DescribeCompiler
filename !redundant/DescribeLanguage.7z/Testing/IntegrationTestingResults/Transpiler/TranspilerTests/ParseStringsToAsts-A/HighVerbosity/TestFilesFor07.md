========================================
Source Code File Names (between the arrows)
========================================

🡆Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic5.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_twoRoots.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments5.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.C_empty1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.C_empty2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.C_empty3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.C_empty4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_cyrillic.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_double_characters1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_double_characters2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_double_characters3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_escaped_double_characters1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_escaped_double_characters2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_escaped_double_characters3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.E_spaces_escapes_N.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.E_spaces_escapes_RN.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production5.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production6.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production7.ds🡄

========================================
Logged text
========================================

🡆Verbosity set to: High
Language version set to: Describe Tags - v0.7
Describe Transpiler initialized.
Starting a 'String[] -> Unfold[]' operation...
STOP_ON_ERROR - False
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic1.ds"
Preprocessed source code - 138 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<QpeudYXy> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'wool fabrics ') T(TAG|'<54vHCQwI>') T(SEPARATOR|',\r\n\t') T(DATA|'cotton fabrics ') T(TAG|'<Ll0bDtIQ>') T(SEPARATOR|',\r\n\t') T(DATA|'silk fabrics ') T(TAG|'<6huM44Hm>') T(SEPARATOR|',\r\n\t') T(DATA|'synthetic fabrics ') T(TAG|'<oAgVUPi0>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 138 characters, into 17 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic2.ds"
Preprocessed source code - 46 characters long

Parsing sequence: T(DATA|'fabrics ') T(HYPHEN|'-') T(RIGHT_ARROW|'> \r\n\t\r\n\t') T(DATA|'synthetic fabrics ') T(TAG|'<i1NLckN6>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 46 characters, into 7 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic3.ds"
Preprocessed source code - 51 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<zAfn39Kh>') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'synthetic fabrics ') T(TAG|'<hOy5oL3B> ') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 51 characters, into 8 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic4.ds"
Preprocessed source code - 146 characters long

Parsing sequence: T(DATA|'fabrics') T(TAG|'<wIcCuax5>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool fabrics') T(TAG|'<C92Mf6yV>') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics') T(TAG|'<TxW3Yetp>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics') T(TAG|'<08yGbnMX>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics') T(TAG|'<7MZTHLMY>') T(TERMINATOR|';\r\n') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 146 characters, into 17 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_basic5.ds"
Preprocessed source code - 153 characters long

Parsing sequence: T(DATA|'fabrics') T(TAG|'<wIcCuax5>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\r\n    ') T(DATA|'wool fabrics') T(TAG|'<C92Mf6yV>') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(TAG|'<TxW3Yetp>') T(SEPARATOR|',\r\n\t\r\n    ') T(DATA|'silk fabrics') T(TAG|'<08yGbnMX>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<7MZTHLMY>') T(TERMINATOR|';\r\n') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 153 characters, into 17 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.A_twoRoots.ds"
Preprocessed source code - 179 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<Zcm0y9mS> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\n\n    ') T(DATA|'fiber ') T(TAG|'<ZxMvmqeZ>') T(SEPARATOR|',\n    ') T(DATA|'water ') T(TAG|'<xePTheNI>') T(TERMINATOR|';\n\n') T(DATA|'micronutrients ') T(TAG|'<l7qy3zi2>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\n\n    ') T(DATA|'vitamins (ABCDEK) ') T(TAG|'<6Nq8AWj7>') T(SEPARATOR|',\n    ') T(DATA|'minerals (micronutrients) ') T(TAG|'<jG4U9bwg>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 179 characters, into 21 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments1.ds"
Preprocessed source code - 166 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<KvtgGtnv> ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<rUEqmXfk>') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(TAG|'<wpra8mUV>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<VFoIEr0T>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<oI5DOuPh>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 166 characters, into 17 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments2.ds"
Preprocessed source code - 172 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<aXLBEer9> ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'cotton fabrics ') T(TAG|'<evhAIQx4>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<h0e5wwEY>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<WryZrSIJ>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 172 characters, into 14 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments3.ds"
Preprocessed source code - 139 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<QuvD4gqX> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>        ') T(DATA|'wool fabrics ') T(TAG|'<VBsu8OpW>') T(SEPARATOR|', ') T(DATA|'cotton fabrics ') T(TAG|'<0RdNAvNs> ') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 139 characters, into 11 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments4.ds"
Preprocessed source code - 185 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<qJobcYNC> ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<WmtITd8B>') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(TAG|'<KGkvDUZH>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<BbiZz4Ie>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<gCWv1P46>') T(TERMINATOR|';\r\n\r\n') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 185 characters, into 17 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.B_comments5.ds"
Preprocessed source code - 181 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<xpXWehDW> ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<TcD3LcoW>') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(TAG|'<thZBzyNc>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<dOlQGMJ4>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<Ln7Y7Dme>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 181 characters, into 17 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.C_empty1.ds"
Preprocessed source code - 21 characters long

Parsing sequence: T(DATA|'fabrics') T(TAG|'<c42Q6wPH> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 21 characters, into 6 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.C_empty2.ds"
Preprocessed source code - 22 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<YACUz3H9> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 22 characters, into 6 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.C_empty3.ds"
Preprocessed source code - 21 characters long

Parsing sequence: T(DATA|'fabrics') T(TAG|'<YMFX0PTE>') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 21 characters, into 6 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.C_empty4.ds"
Preprocessed source code - 29 characters long

Parsing sequence: T(DATA|'fabrics\r\n') T(TAG|'<SIrifQYp>\r\n') T(HYPHEN|'-') T(RIGHT_ARROW|'> \r\n\r\n') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 29 characters, into 6 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_cyrillic.ds"
Preprocessed source code - 148 characters long

Parsing sequence: T(DATA|'платове ') T(TAG|'<ФЛГмссД5> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'вълнени платове ') T(TAG|'<ПеП0ТхЗй>') T(SEPARATOR|',\r\n\t') T(DATA|'памучни платове ') T(TAG|'<ПТъЗАфЪа>') T(SEPARATOR|',\r\n\t') T(DATA|'копринени платове ') T(TAG|'<5Суак3ИЙ>') T(SEPARATOR|',\r\n\t') T(DATA|'синтетични платове ') T(TAG|'<ЛКтрт5КН>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 148 characters, into 17 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_double_characters1.ds"
Preprocessed source code - 165 characters long

Parsing sequence: T(DATA|'fa ') T(HYPHEN|'-') T(DATA|' br') T(HYPHEN|'-') T(DATA|'ics') T(HYPHEN|'-') T(DATA|' ') T(TAG|'<45mns0l-O>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool') T(HYPHEN|'-') T(DATA|'fabrics ') T(TAG|'<-5g1GJyFS>') T(SEPARATOR|',\r\n    ') T(HYPHEN|'-') T(DATA|'cotton fabrics ') T(TAG|'<f75CKWhl->') T(SEPARATOR|',\r\n    ') T(HYPHEN|'-') T(DATA|' silk ') T(HYPHEN|'-') T(DATA|' fabrics ') T(TAG|'<68Es--hujI>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics') T(HYPHEN|'-') T(DATA|' ') T(TAG|'<mWa4QdRm>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 165 characters, into 31 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_double_characters2.ds"
Preprocessed source code - 163 characters long

Parsing sequence: T(DATA|'fa ') T(FORWARD_SLASH|'/ ') T(DATA|'br') T(FORWARD_SLASH|'/') T(DATA|'ics') T(FORWARD_SLASH|'/ ') T(TAG|'<ToUZ5J7e> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool') T(FORWARD_SLASH|'/') T(DATA|'fabrics ') T(TAG|'</DZChUWeh>') T(SEPARATOR|',\r\n    ') T(FORWARD_SLASH|'/') T(DATA|'cotton fabrics ') T(TAG|'<XBru/v3rK>') T(SEPARATOR|',\r\n    ') T(FORWARD_SLASH|'/ ') T(DATA|'silk ') T(FORWARD_SLASH|'/ ') T(DATA|'fabrics') T(TAG|'<7tewYK/BC>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics') T(FORWARD_SLASH|'/') T(TAG|'<qStgB/Iqw>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 163 characters, into 29 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_double_characters3.ds"
Preprocessed source code - 164 characters long

Parsing sequence: T(DATA|'fa ') T(ESCAPE|'\ ') T(DATA|'br') T(ESCAPE|'\') T(DATA|'ics') T(ESCAPE|'\ ') T(TAG|'<AkoHsBxP>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool') T(ESCAPE|'\') T(DATA|'fabrics ') T(TAG|'<\2\2gPwg0Z>') T(SEPARATOR|',\r\n    ') T(ESCAPE|'\') T(DATA|'cotton fabrics ') T(TAG|'<\6KbLpKF2>') T(SEPARATOR|',\r\n    ') T(ESCAPE|'\ ') T(DATA|'silk ') T(ESCAPE|'\ ') T(DATA|'fabrics ') T(TAG|'<YA0\Cn7gP>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics') T(ESCAPE|'\ ') T(TAG|'<V4tLOkb5>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 164 characters, into 29 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_escaped_double_characters1.ds"
Preprocessed source code - 178 characters long

Parsing sequence: T(DATA|'fa ') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'> ') T(DATA|'br') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'>') T(DATA|'ics') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'> ') T(TAG|'<uqkUXoj0>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'>') T(DATA|'fabrics ') T(TAG|'<y3rd1tuM>') T(SEPARATOR|',\r\n    ') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'>') T(DATA|'cotton fabrics') T(TAG|'<l9JX2YWw>') T(SEPARATOR|',\r\n    ') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'> ') T(DATA|'silk ') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'> ') T(DATA|'fabrics  ') T(TAG|'<INIKQpj4>  ') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'>') T(TAG|'<gF7eKSgr> ') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 178 characters, into 37 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_escaped_double_characters2.ds"
Preprocessed source code - 166 characters long

Parsing sequence: T(DATA|'fa ') T(ESCAPE_SEPARATOR|'\, ') T(DATA|'br') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'>') T(DATA|'ics') T(ESCAPE_LCOMMENT|'\// ') T(TAG|'<6O4fovPJ>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool') T(ESCAPE_TERMINATOR|'\;') T(DATA|'fabrics ') T(TAG|'<cTk1qeGz>') T(SEPARATOR|',\r\n    ') T(ESCAPE_SEPARATOR|'\,') T(DATA|'cotton fabrics') T(ESCAPE_LEFT_ARROW|'\<') T(TAG|'<cTk1qeGz>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics') T(TAG|'<cTk1qeGz>  ') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics') T(ESCAPE_TERMINATOR|'\; ') T(TAG|'<cTk1qeGz>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 166 characters, into 28 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.D_escaped_double_characters3.ds"
Preprocessed source code - 169 characters long

Parsing sequence: T(DATA|'fa ') T(ESCAPE_ESCAPE|'\\ ') T(DATA|'br') T(ESCAPE_ESCAPE|'\\') T(DATA|'ics') T(ESCAPE_ESCAPE|'\\ ') T(TAG|'<rDD37re8> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool') T(ESCAPE_ESCAPE|'\\') T(DATA|'fabrics ') T(TAG|'<uCzQa1uW>') T(SEPARATOR|',\r\n    ') T(ESCAPE_ESCAPE|'\\') T(DATA|'cotton fabrics ') T(TAG|'<UxMKgYjI>') T(SEPARATOR|',\r\n    ') T(ESCAPE_ESCAPE|'\\ ') T(DATA|'silk ') T(ESCAPE_ESCAPE|'\\ ') T(DATA|'fabrics ') T(TAG|'<Ux6wwQBT>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics') T(ESCAPE_ESCAPE|'\\ ') T(TAG|'<dbpyUcza>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 169 characters, into 29 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.E_spaces_escapes_N.ds"
Preprocessed source code - 164 characters long

Parsing sequence: T(DATA|'fabric     s \t') T(TAG|'<TSbLGnNG> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\n\n\t') T(DATA|'wool   fabrics\t ') T(TAG|'<QWVZ3pp9> ') T(SEPARATOR|',\n\t') T(DATA|'cotton') T(ESCAPE_SEPARATOR|'\, ') T(DATA|'fabrics textiles   ') T(TAG|'<75NTfebY>') T(SEPARATOR|',\n    ') T(DATA|'silk') T(ESCAPE_HYPHEN|'\-') T(ESCAPE_RIGHT_ARROW|'\>') T(DATA|'fabrics ') T(TAG|'<Sqs0lm7S>') T(SEPARATOR|',\n    ') T(DATA|'syntic \t\tfabrics ') T(TAG|'<GcZEI9gy>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 164 characters, into 22 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.E_spaces_escapes_RN.ds"
Preprocessed source code - 173 characters long

Parsing sequence: T(DATA|'fabric     s    ') T(TAG|'<sJZOzSdo>\t') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'wool   fabrics\t') T(TAG|'<UlJXGWLS> ') T(SEPARATOR|',\r\n\t') T(DATA|'cotton') T(ESCAPE_SEPARATOR|'\, ') T(DATA|'fabrics textiles  ') T(ESCAPE_LEFT_ARROW|'\<') T(TAG|'<d4jKusMe>') T(SEPARATOR|',\r\n    ') T(DATA|'silk') T(ESCAPE_HYPHEN|'\-') T(RIGHT_ARROW|'>') T(DATA|'fabrics ') T(TAG|'<Bgx8/M6B1>') T(SEPARATOR|',\r\n    ') T(DATA|'syntic \t\tfabrics ') T(TAG|'<7vb\\W9VSB>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 173 characters, into 23 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production1.ds"
Preprocessed source code - 137 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<0CmyN2Mb> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'fiber ') T(TAG|'<CMxWzMs5> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<hzAzwlx6>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<UHOcZPAm>') T(TERMINATOR|';\r\n    \r\n    ') T(DATA|'water ') T(TAG|'<BBmOZjJa>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 137 characters, into 18 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production2.ds"
Preprocessed source code - 129 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<eQxYylc3> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'water ') T(TAG|'<tdgS8qBO>') T(SEPARATOR|',\r\n\t') T(DATA|'fiber ') T(TAG|'<OpdFntBx> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<MLUxjdg8>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<qkVgxZIs>') T(TERMINATOR|';') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 129 characters, into 19 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production3.ds"
Preprocessed source code - 155 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<oVs6tsnU> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'water ') T(TAG|'<9Y9uFDwu>') T(SEPARATOR|',\r\n\t') T(DATA|'fiber ') T(TAG|'<PALnQoTQ> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<6hlYVfaz>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<gubSBEDe>') T(TERMINATOR|';\r\n\r\n\t') T(DATA|'somth else ') T(TAG|'<hAyLdw3m>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 155 characters, into 21 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production4.ds"
Preprocessed source code - 262 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<xkQxOfc9> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'fiber ') T(TAG|'<CbALGP8d> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<7KNUmetK>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<6qFQ0HxK>') T(TERMINATOR|';\r\n\t\r\n\t') T(DATA|'science ') T(TAG|'<o8lvOnlB> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\r\n\t\t') T(DATA|'math ') T(TAG|'<SbQjE2YS>') T(SEPARATOR|',\r\n\t\t') T(DATA|'informathics ') T(TAG|'<CVOSiiAS>') T(SEPARATOR|',\r\n\t\t') T(DATA|'medicine ') T(TAG|'<1G0hZLJ4>') T(TERMINATOR|';\r\n    \r\n    ') T(DATA|'water ') T(TAG|'<ozhHnNOU>') T(SEPARATOR|',\r\n    ') T(DATA|'salt ') T(TAG|'<jMBLOKGE>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 262 characters, into 34 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production5.ds"
Preprocessed source code - 254 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<SxOf3elF> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'water ') T(TAG|'<8S3IwDlG>') T(SEPARATOR|',\r\n    ') T(DATA|'salt ') T(TAG|'<RV4OUQoy>') T(SEPARATOR|',\r\n    ') T(DATA|'fiber ') T(TAG|'<G3tWgyDr> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<AwPl7oBK>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<OcIUTGif>') T(TERMINATOR|';\r\n\t\r\n\t') T(DATA|'science ') T(TAG|'<k543P1uB> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\r\n\t\t') T(DATA|'math ') T(TAG|'<IZZ9vPiK>') T(SEPARATOR|',\r\n\t\t') T(DATA|'informathics ') T(TAG|'<OMH9y9Jn>') T(SEPARATOR|',\r\n\t\t') T(DATA|'medicine ') T(TAG|'<UuA1ITf9>') T(TERMINATOR|';') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 254 characters, into 35 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production6.ds"
Preprocessed source code - 318 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<VNvl4KbI> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'fiber ') T(TAG|'<BNdiPBY8> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<47GG8irk>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<vRje122z>') T(TERMINATOR|';\r\n\t\r\n\t') T(DATA|'science ') T(TAG|'<4Zohe6QE> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\r\n\t\t') T(DATA|'math ') T(TAG|'<u87kglXS> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\t') T(DATA|'algebra ') T(TAG|'<VB7KNYBw>') T(SEPARATOR|',\r\n\t\t\t') T(DATA|'geometry ') T(TAG|'<gKznl6RJ>') T(TERMINATOR|';\r\n\t\t\t\r\n\t\t') T(DATA|'informathics ') T(TAG|'<Uon0W1e7>') T(SEPARATOR|',\r\n\t\t') T(DATA|'medicine ') T(TAG|'<rBW9kGDK>') T(TERMINATOR|';\r\n    \r\n    ') T(DATA|'water ') T(TAG|'<3QJz4slg>') T(SEPARATOR|',\r\n    ') T(DATA|'salt ') T(TAG|'<X2BTGncx>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 318 characters, into 41 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor07.F_production_in_production7.ds"
Preprocessed source code - 311 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<ryQ27h6e> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'water ') T(TAG|'<hAdLCBLZ>') T(SEPARATOR|',\r\n    ') T(DATA|'salt ') T(TAG|'<GotVxcPm>') T(SEPARATOR|',\r\n    ') T(DATA|'fiber ') T(TAG|'<CHcd0L0E> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<jiSw0LNV>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<TpR3PZdW>') T(TERMINATOR|';\r\n\t\r\n\t') T(DATA|'science ') T(TAG|'<qlMb3HAO> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\t\r\n\t\t') T(DATA|'informathics ') T(TAG|'<jn0zFcnW>') T(SEPARATOR|',\r\n\t\t') T(DATA|'medicine ') T(TAG|'<JZmdtZj5>') T(SEPARATOR|',\r\n\t\t\r\n\t\t') T(DATA|'math ') T(TAG|'<bYBIKVXn> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\t') T(DATA|'algebra ') T(TAG|'<nFxP8YKb>') T(SEPARATOR|',\r\n\t\t\t') T(DATA|'geometry ') T(TAG|'<hDNMVYP0>') T(TERMINATOR|';') T(TERMINATOR|';') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 311 characters, into 43 tokens.
Those were translated to an AST.
All Files: 31, Succeeded: 31, Failed: 0, Errors: 0🡄

========================================
Produced Unfold
========================================

