========================================
Source Code File Names (between the arrows)
========================================

🡆Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_twoRoots.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments5.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor09.C_cyrillic.ds🡄

========================================
Logged text
========================================

🡆Verbosity set to: High
Language version set to: Describe Decorators - v0.9
Describe Transpiler initialized.
Starting a 'String[] -> Unfold[]' operation...
STOP_ON_ERROR - False
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic1.ds"
Preprocessed source code - 363 characters long

Parsing sequence: T(DATA|'fabrics ') T(LINK|'[https://en.test.org/wiki/List_of_fabrics] ') T(TAG|'<QpeudYXy> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'http') T(PROTO_SLASHES|'://') T(DATA|'fabrics.com wool ') T(LINK|'[https://en.test.org/wiki/Wool] ') T(DECORATOR|'{}') T(TAG|'<54vHCQwI>') T(SEPARATOR|',\r\n\t') T(DATA|'cotton fabrics ') T(LINK|'[https://en.test.org/wiki/Cotton]') T(DECORATOR|'{} ') T(TAG|'<Ll0bDtIQ>') T(SEPARATOR|',\r\n\t') T(DATA|'silk http') T(PROTO_SLASHES|'://') T(DATA|'fabrics.com') T(FORWARD_SLASH|'/') T(DATA|'index.html fabrics ') T(DECORATOR|'{}') T(LINK|'[https://en.test.org/wiki/Silk]') T(TAG|'<6huM44Hm>') T(SEPARATOR|',\r\n\t') T(DATA|'synthetic fabrics') T(DECORATOR|'{} ') T(LINK|'[https://en.test.org/wiki/Synthetic]') T(TAG|'<oAgVUPi0>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 363 characters, into 32 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic2.ds"
Preprocessed source code - 193 characters long

Parsing sequence: T(DATA|'fabrics ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(HYPHEN|'-') T(RIGHT_ARROW|'> \r\n\t\r\n\t') T(DATA|'synthetic fabrics https') T(PROTO_SLASHES|'://') T(DATA|'some') T(HYPHEN|'-') T(DATA|'link') T(FORWARD_SLASH|'/\r\n\t') T(TAG|'<i1NLckN6> \r\n\t') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]\r\n\t') T(DECORATOR|'{\r\n\t\tinfo | more info here\r\n\t}\r\n\t') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 193 characters, into 15 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic3.ds"
Preprocessed source code - 108 characters long

Parsing sequence: T(DATA|'fabrics ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(DECORATOR|'{color | red}') T(TAG|'<zAfn39Kh>') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'synthetic fabrics ') T(TAG|'<hOy5oL3B> ') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 108 characters, into 10 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_basic4.ds"
Preprocessed source code - 432 characters long

Parsing sequence: T(DATA|'fabrics') T(TAG|'<wIcCuax5>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool fabrics') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TAG|'<C92Mf6yV>') T(SEPARATOR|',\r\n\t\r\n    ') T(DATA|'cotton fabrics') T(TAG|'<TxW3Yetp> ') T(DECORATOR|'{color | green}\r\n\t') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]\r\n\t') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n\r\n    ') T(DATA|'silk fabrics (https') T(PROTO_SLASHES|'://') T(DATA|'www.notube.com') T(FORWARD_SLASH|'/') T(DATA|'watch?v=hTui12lKus) ') T(TAG|'<08yGbnMX>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics (ftp') T(PROTO_SLASHES|'://') T(DATA|'www.notube.com') T(FORWARD_SLASH|'/') T(DATA|'watch?v=hTui12lKus)') T(TAG|'<7MZTHLMY>') T(TERMINATOR|';\r\n') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 432 characters, into 30 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.A_twoRoots.ds"
Preprocessed source code - 332 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<Zcm0y9mS> \r\n') T(DECORATOR|'{icon | nutrients.png}\r\n') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'fiber ') T(TAG|'<ZxMvmqeZ> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'water ') T(TAG|'<xePTheNI> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';\r\n\r\n') T(DATA|'micronutrients ') T(LINK|'[] ') T(DECORATOR|'{icon | micronutrients.png} ') T(TAG|'<l7qy3zi2>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'vitamins (ABCDEK) ') T(TAG|'<6Nq8AWj7>') T(SEPARATOR|',\r\n    ') T(DATA|'minerals (micronutrients) ') T(TAG|'<jG4U9bwg>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 332 characters, into 26 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments1.ds"
Preprocessed source code - 336 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<KvtgGtnv>') T(LINK|'[] ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<rUEqmXfk>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(DECORATOR|'{decorator}') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(DECORATOR|'{decorator}') T(TAG|'<wpra8mUV>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<VFoIEr0T>') T(LINK|'[]') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<oI5DOuPh>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 336 characters, into 23 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments2.ds"
Preprocessed source code - 275 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<aXLBEer9> ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'cotton fabrics ') T(TAG|'<evhAIQx4>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<h0e5wwEY> ') T(LINK|'[]') T(DECORATOR|'{}') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<WryZrSIJ>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 275 characters, into 16 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments3.ds"
Preprocessed source code - 245 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<QuvD4gqX> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>        ') T(DATA|'wool fabrics ') T(TAG|'<VBsu8OpW>') T(SEPARATOR|', ') T(DATA|'cotton fabrics ') T(TAG|'<0RdNAvNs> ') T(DECORATOR|'{dec} ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 245 characters, into 13 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments4.ds"
Preprocessed source code - 400 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<qJobcYNC> ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<WmtITd8B>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(DECORATOR|'{decorator}') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(TAG|'<KGkvDUZH>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(DECORATOR|'{ de c   or a \t\ttor}') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<BbiZz4Ie>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<gCWv1P46>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';\r\n\r\n') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 400 characters, into 23 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.B_comments5.ds"
Preprocessed source code - 365 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<xpXWehDW> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<TcD3LcoW>') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(TAG|'<thZBzyNc>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<dOlQGMJ4>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<Ln7Y7Dme>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 365 characters, into 21 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor09.C_cyrillic.ds"
Preprocessed source code - 274 characters long

Parsing sequence: T(DATA|'платове ') T(TAG|'<ФЛГмссД> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'вълнени платове ') T(TAG|'<ПеП0ТхЗй>') T(LINK|'[https://www.домейн.com/watch?v=hTui12lKus] ') T(DECORATOR|'{декоратор}') T(SEPARATOR|',\r\n\t') T(DATA|'памучни платове ') T(TAG|'<ПТъЗАфЪа>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(DECORATOR|'{декоратори}') T(DECORATOR|'{деко ратор-иййй}') T(SEPARATOR|',\r\n\t') T(DATA|'копринени платове ') T(TAG|'<5Суак3ИЙ>') T(SEPARATOR|',\r\n\t') T(DATA|'синтетични платове ') T(TAG|'<ЛКтрт5КН>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 274 characters, into 22 tokens.
Those were translated to an AST.
All Files: 11, Succeeded: 11, Failed: 0, Errors: 0🡄

========================================
Produced Unfold
========================================

