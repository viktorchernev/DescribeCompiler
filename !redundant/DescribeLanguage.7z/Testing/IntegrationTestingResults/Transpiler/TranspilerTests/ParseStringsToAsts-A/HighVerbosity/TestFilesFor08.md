========================================
Source Code File Names (between the arrows)
========================================

🡆Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_basic1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_basic2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_basic3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_basic4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_twoRoots.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments5.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.C_empty1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.C_empty2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.C_empty3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.D_cyrillic.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.D_escaped_double_characters1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.E_spaces_escapes_N.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.E_spaces_escapes_RN.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production1.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production2.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production3.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production4.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production5.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production6.ds
Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production7.ds🡄

========================================
Logged text
========================================

🡆Verbosity set to: High
Language version set to: Describe Links - v0.8
Describe Transpiler initialized.
Starting a 'String[] -> Unfold[]' operation...
STOP_ON_ERROR - False
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_basic1.ds"
Preprocessed source code - 337 characters long

Parsing sequence: T(DATA|'fabrics ') T(LINK|'[https://en.test.org/wiki/List_of_fabrics] ') T(TAG|'<QpeudYXy> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'wool fabrics ') T(LINK|'[https://en.test.org/wiki/Wool | wikipedia] ') T(TAG|'<54vHCQwI>') T(SEPARATOR|',\r\n\t') T(DATA|'cotton fabrics ') T(LINK|'[https://en.test.org/wiki/Cotton] ') T(TAG|'<Ll0bDtIQ>') T(SEPARATOR|',\r\n\t') T(DATA|'silk fabrics ') T(LINK|'[https://en.test.org/wiki/Silk | test.org]') T(TAG|'<6huM44Hm>') T(SEPARATOR|',\r\n\t') T(DATA|'synthetic fabrics ') T(LINK|'[https://en.test.org/wiki/Synthetic]') T(TAG|'<oAgVUPi0>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 337 characters, into 22 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_basic2.ds"
Preprocessed source code - 133 characters long

Parsing sequence: T(DATA|'fabrics ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(HYPHEN|'-') T(RIGHT_ARROW|'> \r\n\t\r\n\t') T(DATA|'synthetic fabrics ') T(TAG|'<i1NLckN6> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 133 characters, into 9 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_basic3.ds"
Preprocessed source code - 94 characters long

Parsing sequence: T(DATA|'fabrics ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TAG|'<zAfn39Kh>') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'synthetic fabrics ') T(TAG|'<hOy5oL3B> ') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 94 characters, into 9 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_basic4.ds"
Preprocessed source code - 348 characters long

Parsing sequence: T(DATA|'fabrics') T(TAG|'<wIcCuax5>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool fabrics') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TAG|'<C92Mf6yV>') T(SEPARATOR|',\r\n\t\r\n    ') T(DATA|'cotton fabrics') T(TAG|'<TxW3Yetp>\r\n\t') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus | notube]\r\n\t') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus | yestube]') T(SEPARATOR|',\r\n\r\n    ') T(DATA|'silk fabrics') T(TAG|'<08yGbnMX>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics') T(TAG|'<7MZTHLMY>') T(TERMINATOR|';\r\n') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 348 characters, into 21 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.A_twoRoots.ds"
Preprocessed source code - 278 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<Zcm0y9mS> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'fiber ') T(TAG|'<ZxMvmqeZ> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'water ') T(TAG|'<xePTheNI> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';\r\n\r\n') T(DATA|'micronutrients ') T(LINK|'[] ') T(TAG|'<l7qy3zi2>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'vitamins (ABCDEK) ') T(TAG|'<6Nq8AWj7>') T(SEPARATOR|',\r\n    ') T(DATA|'minerals (micronutrients) ') T(TAG|'<jG4U9bwg>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 278 characters, into 24 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments1.ds"
Preprocessed source code - 300 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<KvtgGtnv>') T(LINK|'[] ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<rUEqmXfk>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TAG|'<wpra8mUV>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<VFoIEr0T>') T(LINK|'[]') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<oI5DOuPh>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 300 characters, into 21 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments2.ds"
Preprocessed source code - 265 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<aXLBEer9> ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'cotton fabrics ') T(TAG|'<evhAIQx4>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<h0e5wwEY> ') T(LINK|'[]') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<WryZrSIJ>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 265 characters, into 15 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments3.ds"
Preprocessed source code - 226 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<QuvD4gqX> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>        ') T(DATA|'wool fabrics ') T(TAG|'<VBsu8OpW>') T(SEPARATOR|', ') T(DATA|'cotton fabrics ') T(TAG|'<0RdNAvNs> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 226 characters, into 12 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments4.ds"
Preprocessed source code - 357 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<qJobcYNC> ') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<WmtITd8B>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(TAG|'<KGkvDUZH>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<BbiZz4Ie>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<gCWv1P46>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';\r\n\r\n') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 357 characters, into 21 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.B_comments5.ds"
Preprocessed source code - 353 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<xpXWehDW> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(HYPHEN|'-') T(RIGHT_ARROW|'> ') T(DATA|'wool fabrics ') T(TAG|'<TcD3LcoW>') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(TAG|'<thZBzyNc>') T(SEPARATOR|',\r\n    ') T(DATA|'silk fabrics ') T(TAG|'<dOlQGMJ4>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<Ln7Y7Dme>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 353 characters, into 21 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.C_empty1.ds"
Preprocessed source code - 64 characters long

Parsing sequence: T(DATA|'fabrics') T(TAG|'<c42Q6wPH>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(HYPHEN|'-') T(RIGHT_ARROW|'>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 64 characters, into 7 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.C_empty2.ds"
Preprocessed source code - 65 characters long

Parsing sequence: T(DATA|'fabrics ') T(TAG|'<YACUz3H9> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(HYPHEN|'-') T(RIGHT_ARROW|'>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 65 characters, into 7 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.C_empty3.ds"
Preprocessed source code - 123 characters long

Parsing sequence: T(DATA|'fabrics\r\n') T(TAG|'<SIrifQYp>\r\n') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]\r\n') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]\r\n') T(LINK|'[]\r\n') T(HYPHEN|'-') T(RIGHT_ARROW|'> \r\n\r\n') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 123 characters, into 9 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.D_cyrillic.ds"
Preprocessed source code - 233 characters long

Parsing sequence: T(DATA|'платове ') T(TAG|'<ФЛГмссД> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'вълнени платове ') T(TAG|'<ПеП0ТхЗй>') T(LINK|'[https://www.домейн.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n\t') T(DATA|'памучни платове ') T(TAG|'<ПТъЗАфЪа>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n\t') T(DATA|'копринени платове ') T(TAG|'<5Суак3ИЙ>') T(SEPARATOR|',\r\n\t') T(DATA|'синтетични платове ') T(TAG|'<ЛКтрт5КН>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 233 characters, into 19 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.D_escaped_double_characters1.ds"
Preprocessed source code - 239 characters long

Parsing sequence: T(DATA|'fa brics ') T(TAG|'<6O4fovPJ>') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'wool fabrics ') T(TAG|'<cTk1qeGz>') T(SEPARATOR|',\r\n    ') T(DATA|'cotton fabrics ') T(ESCAPE_LEFT_SQUARE|'\[') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TAG|'<evssLum4>') T(SEPARATOR|',\r\n    ') T(DATA|'silk ') T(ESCAPE_LEFT_SQUARE|'\[') T(DATA|'https') T(PROTO_SLASHES|'://') T(DATA|'www.notube.com') T(FORWARD_SLASH|'/') T(DATA|'watch?v=hTui12lKus') T(ESCAPE_RIGHT_SQUARE|'\]') T(DATA|'fabrics') T(TAG|'<WR31xpLW>') T(SEPARATOR|',\r\n    ') T(DATA|'synthetic fabrics ') T(TAG|'<sfObQkOm>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 239 characters, into 27 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.E_spaces_escapes_N.ds"
Preprocessed source code - 351 characters long

Parsing sequence: T(DATA|'fabric     s \t') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]     ') T(TAG|'<TSbLGnNG> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'wool   fabrics\t ') T(TAG|'<QWVZ3pp9> ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n\t') T(DATA|'cotton') T(ESCAPE_LEFT_SQUARE|'\[ ') T(DATA|'fabrics textiles ') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]   ') T(TAG|'<75NTfebY>') T(SEPARATOR|',\r\n    ') T(DATA|'silk') T(ESCAPE_LEFT_SQUARE|'\[') T(ESCAPE_LEFT_SQUARE|'\[') T(ESCAPE_LEFT_SQUARE|'\[') T(ESCAPE_RIGHT_SQUARE|'\]') T(DATA|'fabrics ') T(TAG|'<Sqs0lm7S>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'syntic \t\tfabrics ') T(TAG|'<GcZEI9gy>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 351 characters, into 28 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.E_spaces_escapes_RN.ds"
Preprocessed source code - 297 characters long

Parsing sequence: T(DATA|'fabric     s    ') T(TAG|'<sJZOzSdo>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]\t') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'wool   fabrics') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]\t') T(TAG|'<UlJXGWLS>') T(SEPARATOR|',\r\n\t') T(DATA|'cotton') T(ESCAPE_SEPARATOR|'\, ') T(DATA|'fabrics textiles  ') T(ESCAPE_RIGHT_SQUARE|'\]') T(TAG|'<d4jKusMe>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'silk') T(ESCAPE_LEFT_SQUARE|'\[') T(DATA|'fabrics ') T(TAG|'<Bgx8M6B1>') T(SEPARATOR|',\r\n    ') T(DATA|'syntic \t\tfabrics ') T(TAG|'<7vbW9VSB>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 297 characters, into 25 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production1.ds"
Preprocessed source code - 159 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<0CmyN2Mb> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'fiber ') T(TAG|'<CMxWzMs5> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(LINK|'[http://testlink.com/]') T(TAG|'<hzAzwlx6>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<UHOcZPAm>') T(TERMINATOR|';\r\n    \r\n    ') T(DATA|'water ') T(TAG|'<BBmOZjJa>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 159 characters, into 19 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production2.ds"
Preprocessed source code - 173 characters long

Parsing sequence: T(DATA|'macronutrients ') T(LINK|'[http://testlink.com/]') T(TAG|'<eQxYylc3> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'water ') T(TAG|'<tdgS8qBO>') T(SEPARATOR|',\r\n\t') T(DATA|'fiber ') T(TAG|'<OpdFntBx> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(LINK|'[http://testlink.com/]') T(TAG|'<MLUxjdg8>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<qkVgxZIs>') T(TERMINATOR|';') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 173 characters, into 21 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production3.ds"
Preprocessed source code - 243 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<oVs6tsnU> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'water ') T(TAG|'<9Y9uFDwu>') T(SEPARATOR|',\r\n\t') T(DATA|'fiber ') T(TAG|'<PALnQoTQ>') T(LINK|'[http://testlink.com/] ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(LINK|'[http://testlink.com/]') T(TAG|'<6hlYVfaz>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(LINK|'[http://testlink.com/]') T(TAG|'<gubSBEDe>') T(TERMINATOR|';\r\n\r\n\t') T(DATA|'somth else ') T(LINK|'[http://testlink.com/]') T(TAG|'<hAyLdw3m>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 243 characters, into 25 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production4.ds"
Preprocessed source code - 308 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<xkQxOfc9> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'fiber ') T(TAG|'<CbALGP8d> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<7KNUmetK>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(LINK|'[http://testlink.com/] ') T(TAG|'<6qFQ0HxK>') T(TERMINATOR|';\r\n\t\r\n\t') T(DATA|'science ') T(TAG|'<o8lvOnlB> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\r\n\t\t') T(DATA|'math ') T(TAG|'<SbQjE2YS>') T(SEPARATOR|',\r\n\t\t') T(DATA|'informathics ') T(TAG|'<CVOSiiAS>') T(SEPARATOR|',\r\n\t\t') T(DATA|'medicine ') T(LINK|'[http://testlink.com/] ') T(TAG|'<1G0hZLJ4>') T(TERMINATOR|';\r\n    \r\n    ') T(DATA|'water ') T(TAG|'<ozhHnNOU>') T(SEPARATOR|',\r\n    ') T(DATA|'salt ') T(TAG|'<jMBLOKGE>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 308 characters, into 36 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production5.ds"
Preprocessed source code - 298 characters long

Parsing sequence: T(DATA|'macronutrients ') T(LINK|'[http://testlink.com/]') T(TAG|'<SxOf3elF> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'water ') T(TAG|'<8S3IwDlG>') T(SEPARATOR|',\r\n    ') T(DATA|'salt ') T(TAG|'<RV4OUQoy>') T(SEPARATOR|',\r\n    ') T(DATA|'fiber ') T(TAG|'<G3tWgyDr> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<AwPl7oBK>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<OcIUTGif>') T(TERMINATOR|';\r\n\t\r\n\t') T(DATA|'science ') T(LINK|'[http://testlink.com/]') T(TAG|'<k543P1uB> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\r\n\t\t') T(DATA|'math ') T(TAG|'<IZZ9vPiK>') T(SEPARATOR|',\r\n\t\t') T(DATA|'informathics ') T(TAG|'<OMH9y9Jn>') T(SEPARATOR|',\r\n\t\t') T(DATA|'medicine ') T(TAG|'<UuA1ITf9>') T(TERMINATOR|';') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 298 characters, into 37 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production6.ds"
Preprocessed source code - 340 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<VNvl4KbI> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n    ') T(DATA|'fiber ') T(TAG|'<BNdiPBY8> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<47GG8irk>') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<vRje122z>') T(TERMINATOR|';\r\n\t\r\n\t') T(DATA|'science ') T(TAG|'<4Zohe6QE> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\r\n\t\t') T(DATA|'math ') T(TAG|'<u87kglXS> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\t') T(DATA|'algebra ') T(LINK|'[http://testlink.com/]') T(TAG|'<VB7KNYBw>') T(SEPARATOR|',\r\n\t\t\t') T(DATA|'geometry ') T(TAG|'<gKznl6RJ>') T(TERMINATOR|';\r\n\t\t\t\r\n\t\t') T(DATA|'informathics ') T(TAG|'<Uon0W1e7>') T(SEPARATOR|',\r\n\t\t') T(DATA|'medicine ') T(TAG|'<rBW9kGDK>') T(TERMINATOR|';\r\n    \r\n    ') T(DATA|'water ') T(TAG|'<3QJz4slg>') T(SEPARATOR|',\r\n    ') T(DATA|'salt ') T(TAG|'<X2BTGncx>') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 340 characters, into 42 tokens.
Those were translated to an AST.
------------------------
Starting a parse operation on "Tests.Integration.Transpiler.TestFiles.TestFilesFor08.F_production_in_production7.ds"
Preprocessed source code - 569 characters long

Parsing sequence: T(DATA|'macronutrients ') T(TAG|'<ryQ27h6e>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n\t') T(DATA|'water ') T(TAG|'<hAdLCBLZ>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'salt ') T(TAG|'<GotVxcPm>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n    ') T(DATA|'fiber ') T(TAG|'<CHcd0L0E>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus] ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\r\n        ') T(DATA|'what ') T(TAG|'<jiSw0LNV>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(SEPARATOR|',\r\n        ') T(DATA|'not ') T(TAG|'<TpR3PZdW>') T(LINK|'[https://www.notube.com/watch?v=hTui12lKus]') T(TERMINATOR|';\r\n\t\r\n\t') T(DATA|'science ') T(TAG|'<qlMb3HAO> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\t\r\n\t\t') T(DATA|'informathics ') T(TAG|'<jn0zFcnW>') T(SEPARATOR|',\r\n\t\t') T(DATA|'medicine ') T(TAG|'<JZmdtZj5>') T(SEPARATOR|',\r\n\t\t\r\n\t\t') T(DATA|'math ') T(TAG|'<bYBIKVXn> ') T(HYPHEN|'-') T(RIGHT_ARROW|'>\r\n\t\t\t') T(DATA|'algebra ') T(TAG|'<nFxP8YKb>') T(SEPARATOR|',\r\n\t\t\t') T(DATA|'geometry ') T(TAG|'<hDNMVYP0>') T(TERMINATOR|';') T(TERMINATOR|';') T(TERMINATOR|';') T(EOF|'<EOF>') Ok

Source code parsed successfully
Parse tree unfolded successfully
Done!
------------------------
Parser red 569 characters, into 49 tokens.
Those were translated to an AST.
All Files: 24, Succeeded: 24, Failed: 0, Errors: 0🡄

========================================
Produced Unfold
========================================

