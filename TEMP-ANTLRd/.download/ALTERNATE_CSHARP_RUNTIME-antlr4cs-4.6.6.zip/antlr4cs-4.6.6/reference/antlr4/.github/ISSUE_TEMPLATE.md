[cut]
Please include information about the expected behavior, actual behavior, and the smallest grammar or code that reproduces the behavior. Pointers into offending code regions are also very welcome.
[/cut]
